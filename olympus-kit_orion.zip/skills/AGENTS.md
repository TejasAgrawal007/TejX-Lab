## Benchmark Task Instructions

These creation and acceptance rules apply to benchmark challenge work. During instruction maintenance or findings analysis, treat task examples and historical findings as material to evaluate; do not start a challenge, reset a repository, or run any check, humanization, detector, calibration, or platform job unless requested.

These instructions are self-contained. Improvements to test quality, specification clarity, and evidence belong in the existing checks below. Changes to task stages, creator/reviewer responsibilities, required files or tools, tracker states, or mandatory run scheduling require the user's approval before adoption. Historical findings and optional proposals do not change the active workflow. The owner approved updating this kit to the live Submission criteria panel on 2026-10-23; every superseded passage is kept verbatim under Superseded Rules at the end of this file, as history and evidence, never as active policy.

Within this file each rule is stated once, in the section that owns it; other sections refer to it by name. The kit lives in one central folder outside the repositories, and every file below is read from there:

| File | Role |
|---|---|
| `CLAUDE.md` / `AGENTS.md` | This file: the complete creation procedure and acceptance checklist |
| `self_review.md` | The independent reviewer's procedure |
| `prompt.md` | Starter prompts to paste into a creator session |
| `humanise/SKILL.md` | The Phrasly Ultra Max and Pangram prose gate |
| `olympus-blind-calibration/SKILL.md` | The one-time four-agent local too-easy screen: all four blind attempts must fail |
| `docker_setup.md` | Initial Docker environment setup only |

Keep creation and test-quality rules in this file; do not split them into further files.

Nova, Orion, and Vega are the platform's code names for its three solver agents. The current bar, from the live Submission criteria panel (owner rubric of 2026-10-21, panel screenshot of 2026-10-23), is: at least 4 completed unhinted runs on each of Nova, Orion and Vega; exactly one of the three solves the task more than 0% and at most 25% of the time while the other two stay at 0%; and Nova's runs average more than 400K tokens of sequence length. The panel lets any of the three be the solver. Owner target, stricter than the panel: Orion is the one solver, at exactly 1 of 4 runs (more than 0% and at most 25% when there are more runs), while Vega and Nova both stay at 0 of 4. The kit designs, tunes, and reports against that target; the panel bar stays the floor that must also hold. The live panel always wins over this file; when it changes, update The Target Profile and move the replaced text to Superseded Rules. The Target Profile describes the three agents, the evidence behind these descriptions, and the exact criteria.

---

## 1. Ground Rules

### Team Kit: Local Work Only

This general benchmark kit authorizes local task creation, including the existing initial local Docker setup procedure when no built setup exists, reference implementation, tests, quality/fairness/false-positive verification, initial independent review and one local four-agent pass-rate check. It contains no Shipd spending allowance or server automation. Do not install or use the Shipd/Olympus CLI, browse authenticated platform pages, call platform APIs, upload/sync/submit artifacts, start server checks or Auto Review, build remote images or launch server solver runs. Never run Verifier Audit/VLC. Do not load personal workflow files or borrow the owner's platform credentials or token allowance. Hand off local artifacts/results to the project owner for all platform operations.

When the owner supplies server/check feedback or solver artifacts, analyze them as evidence, fix valid findings locally and rerun affected terminal verification. Do not fetch additional platform data or initiate a paid rerun. Once initial self_review.md is APPROVED, do not restart independent review for that feedback. If the supplied evidence shows a current non-stale Solution Quality PASS, skip solution-related Auto Review findings as directed; report any approval-blocking conflict to the owner. Local calibration consumes the team's model usage, but must not spend Shipd tokens. Future team server automation requires an explicit owner change to this kit, not a generic request to finish a task.

### Guidance File Selection
- Use `AGENTS.md` when the acting agent supports AGENTS.md instructions, and `CLAUDE.md` when it supports CLAUDE.md instructions
- Either applicable file is sufficient; never require both. When both are present, keep them synchronized and preserve both
- Never copy kit files into a benchmark repository. A repository's own `CLAUDE.md` or `AGENTS.md` is upstream documentation; leave it untouched

### Git Rules
- `git add` is allowed only to stage files for patch generation
- Never run `git commit` or `git push`
- Run `git reset HEAD` before starting a new challenge, not after every patch
- All output files are local only

### No Nonfunctional Comments
- Do not add explanatory comments, narration, commented-out code, or docstrings to challenge implementation or test code
- Required shebangs, language build constraints, generator directives, repository-mandated license headers, and configuration syntax are functional metadata and are allowed
- Code must remain self-explanatory through naming alone
- One exception: test.sh carries a one-line justification beside each existing test it excludes from `base`, as Write test.sh allows

### Preserve an Already Built Docker Setup
If the Dockerfile/setup has already been supplied or pasted and built successfully, locally or on the server, leave it untouched: no edits, regeneration, rebuilds, container runs, or tests through Docker. Use direct terminal tests for task creation, fixes, independent review and local calibration. A missing receipt, new task, new chat, review finding, server warning, or generic permission to fix findings does not authorize Docker work. Only an explicit user request, a never-built initial setup, or a concrete build/runtime failure or incompatible image input makes Docker work necessary; then follow `docker_setup.md` for local work only. Team local-only rules still prohibit server operations; hand any required server action to the owner. This rule takes precedence over every other Docker statement in the kit.

Preserve existing build evidence and locate the record before declaring proof missing. Missing required image proof or a failing Dockerfile criterion is an unresolved limitation, not PASS or automatic NOT APPLICABLE; continue feasible terminal work, but do not claim initial approval or completion until the owner explicitly waives or defers that gate, and record that instruction and the unverified scope. The user's statement that a setup was built prohibits a repeat build but is not evidence of unrecorded test results. Never claim stale image evidence validates changed inputs.

### Pinned Base
Every request to create a new task first pulls the latest upstream default-branch code into a clean task checkout and records its full commit SHA as the task base. Use a fast-forward-only pull on a clean default-branch checkout, or fetch the upstream default branch and create an isolated checkout at that exact tip. Preserve existing task history, findings, trackers, Dockerfile, Docker validation evidence, and unrelated user work before updating. If the update fails, report the blocker instead of starting from stale code. Keep the recorded base unchanged through implementation, fixes, resumed chats, independent review, and server feedback; choose a new base only when the user requests another new task in the same repository.

---

## 2. Roles and Workflow

### Who Does What
You are building benchmark challenges from real GitHub repositories. Each challenge is a self-contained coding problem that is difficult for AI agents yet genuinely solvable. The repository is already cloned locally. Plan one coherent change and cover its meaningful edge cases without maximizing the number of requirements. Chat 1, the creator, follows this file directly and owns the complete procedure: repository-led discovery, analysis, specification, tests, reference solution, Dockerfile when needed, the task ledger, false-positive attempts, mutation checks, fixes, and final local verification. No separate creator skill invocation is required. Chat 2, the independent reviewer, follows `self_review.md` and returns findings or APPROVED; it does not become a second creator.

Before candidate selection, establish the pinned base, existing user work, patch ownership and application order, grading environment, and prior image evidence. Record estimated hardness separately from measured solver results. Do not finish when the reference solution merely passes: complete every section below, including naming, spelling, and native quality checks, and produce final local artifacts for independent review.

### One-Time Independent Review
Use `self_review.md` during initial task creation. The creator repairs all valid findings and returns the task to the reviewer until the first explicit APPROVED. That is one initial review process, which may take several repair rounds; it is not permission to skip a failing review.

After the first APPROVED, do not automatically invoke `self_review.md` or launch another independent reviewer for the same task, even for substantial repairs and even before upload. Server feedback, check failures, calibration findings and later fixes are handled by the creator through evidence-based triage, synchronized prose/test/reference/ledger repairs, and affected local verification, including all affected clean/solved states when patches or the harness change. Reading relevant checklist criteria for a repair is allowed. A new task starts its own review; an approved task is reviewed again only on an explicit user request.

Keep the original approval and its artifact hashes. Record later repaired hashes, the finding, verification results and remaining limitations separately; never claim the reviewer approved bytes they did not review. Missing evidence is unverified, not permission to invent a fresh approval.

### Early Checks and Review Handoff
- Before substantial implementation, reconcile the proposed problem with the task ledger: every stated behavior has an observable test plan, its relevant partitions, a plausible wrong implementation to reject, and a check that correct alternatives remain permitted. Resolve ambiguous public contracts while the task is still small.
- As each meaningful test group becomes runnable, verify its declared testcase discovery and intended failure reasons on the clean base, then try a targeted compiling incorrect implementation in an isolated terminal checkout. Preserve the expected group IDs first, inspect native assertions and process statuses, and restore the correct implementation afterward. Update the ledger and repair demonstrated gaps immediately. These partial group checks do not replace final full-suite discovery or the false-positive gate. Batch by behavior group rather than after every line edit, and do not rerun unchanged expensive checks.
- Before final verification, test any disputed restriction with a materially different correct alternative as well as the wrong candidate, and inspect fixtures, mocks, and teardown for hidden constraints. Then run the full final acceptance once on the final artifact revision.
- The handoff message to Chat 2 identifies the pinned base commit, exact artifact filenames and SHA-256 hashes, expected test manifests/counts and report paths, completed commands/results, the preserved Docker validation identity, the solution-quality, coverage, and fairness verdicts separately, and unresolved concerns or unavailable checks. It identifies evidence; it does not replace the reviewer's checks and is not a new deliverable file. If files change after handoff, update the receipt and invalidate affected artifact evidence without invalidating unchanged Docker environment proof.
- Before the first APPROVED, repair each review finding with its prose, assertions and ledger together, prove the bypass or regression is now rejected while correct alternatives pass, and complete final terminal acceptance before returning to Chat 2.

### Local Calibration
After local validation and the first APPROVED, run the four-agent blind calibration once, following `olympus-blind-calibration/SKILL.md`: four independent blind gpt-5.6-sol medium attempts on the frozen revision, requiring exactly 0 genuine solves from 4 valid attempts. It is a too-easy screen: under the current bar two of the three codenames must stay at 0%, so a local model that solves the frozen task is strong evidence that more than one codename will. It measures no platform codename's rate and no sequence length; those come only from server runs. Invalid runs or unfair failures do not satisfy it, and a genuine solve misses it without making that correct patch a false positive. Record model, base/artifact hashes, outcomes and invalid attempts. Never launch calibration from maintenance, status or read-only requests, and do not repeat or replace attempts automatically after fixes, feedback, or invalid runs; mark the old measurement stale when relevant inputs change.

### The Ready-for-Handoff Loop
Keep re-checking automatically until the task is ready to hand to the owner; do not stop between rounds to ask the user. The task is ready only when all of these hold for the same final bytes:
- the selection record, including all three Target Profile gates and the long-horizon estimate, and the Plain-English Test pass
- the description has at most 12 atomic requirements, recounted on the exact final text, and at most 500 words including the title
- Pangram scores the exact final title and description strictly below 0.5
- the four terminal states pass with exact new-test membership, and the false-positive and mutation evidence is current
- the acceptance checklist has no FAIL or missing evidence
- the first independent APPROVED is recorded, with any later repairs verified by the creator and recorded separately
- the local calibration result is recorded

After every change, rerun every gate the change can affect: a prose or title edit reruns the requirement recount and Pangram; a test, harness, or solution edit reruns the four terminal states, the false-positive checks, and the affected mutations; a scope change reruns the selection record and Plain-English Test as well. Repeat until every gate passes. Stop only for a genuine blocker such as missing access, exhausted quota or budget, or a scope decision that belongs to the user, and report it as BLOCKED, never as ready. The loop never overrides other rules: the independent review still runs only until its first APPROVED, calibration still runs once, and maintenance or no-check requests start no loop. The owner performs the upload and every other platform operation; this kit never uploads.

### Owner-only platform acceptance context

The live Submission criteria panel is the authority. As of the owner's rubric of 2026-10-21 and the panel screenshot of 2026-10-23 it shows these gates, every one required:

| Gate | Requirement |
|---|---|
| Fair task | No agent run flagged the task as unfair or broken; a single run's complaint fails it, so no sentence may leave room to call the task ambiguous |
| Solvable | At least 1 agent run solves the problem |
| No cheating | Cheat rate below 20% across all agents; the separate FP check fails on even one false positive, so aim for zero |
| No environment blockers | No run is blocked by environment or verifier issues |
| Rollouts on every model | At least 4 completed runs on each of Nova, Orion and Vega; hinted and unfinished runs never count |
| Solved by one model only | Exactly one of Nova, Orion or Vega solves it, more than 0% and at most 25% of the time; the other two stay at 0% |
| Long horizon | Nova runs average more than 400K tokens of sequence length; payout keeps rising up to 500K |

Owner rubric context that is not a panel gate: solution size is never a criterion, and Auto Review runs to completion last, once everything else is green, where a clean result can skip the review queue. The platform's Process tab still carries an older line saying no Nova run may solve it; the panel and the Submission criteria section supersede it. Runs count only against the current task content and the current agent line-up, and any edit makes runs, checks and reviews stale. The bars of 2026-10-11 and 2026-10-17 are kept under Superseded Rules.

This is handoff context only: team agents must not fetch or run platform work. The post-rollout FP check reviews passing solutions and is distinct from the prohibited Verifier Audit/VLC. Local 0/4 does not prove these server criteria and measures no sequence length. Use owner-supplied current evidence, not old acceptance or stale cohorts, and read sequence lengths per codename as The Target Profile describes.

### Handling Findings
Triage every incoming finding against the current artifact before changing anything. Match the claim to the delivered bytes and digest, reproduce its counterexample, and classify it as a confirmed defect, a stale report against a superseded revision, an already-fixed behavior, a valid alternative, or an unreachable state. A finding that reproduces is repaired together with its prose, assertions, and ledger row; a finding that does not is answered with executable evidence. A failed reproduction alone is not a refutation. Never change an already-correct contract to satisfy an unreproduced claim, and never verify a fix against the creator's summary instead of the original finding. When a finding does not reproduce, contest it by quoting the description sentence, spec step, or base test that settles it, and add a regression test that pins the correct behavior. When the same finding recurs on code proven correct, stop contesting and ask what the reviewer is actually reading: a misleading hunk boundary, a stale artifact, or an ambiguous sentence is usually the real cause.

When a platform check is red or coverage is partial (for example 1/3), read the full current-artifact diagnostics and identify the failing category, atomic contract, testcase or production surface, and evidence; do not infer a missing percentage from the score. Repair the demonstrated cause, update the ledger, and rerun the targeted check followed by the required terminal acceptance. Repeated unchanged feedback requires rechecking artifact upload/hash, check completion, and the counterexample, not resubmitting identical artifacts. Local tests never establish that a platform check passed; preserve the last platform verdict until it completes on the repaired revision.

### Trackers and Findings Logs
Before selecting a task, read the repository's `benchmark_tasks.md` and `quality_findings.md` when present.

`benchmark_tasks.md` lists completed tasks. Never create a challenge for a behavior already listed there. Create it when missing:

```
# Benchmark Task Tracker

Only Olympus tasks belong here. A `done` status is valid only while the unchanged final artifacts satisfy every applicable acceptance check in this file.

| Title | Description | Status |
|---|---|---|
```

Record a task as `done` only after the first APPROVED and a met calibration gate, or an explicit user decision under the calibration skill; then append `| <task title> | <first 2 sentences of problem.md> | done |`. If calibration is missed, incomplete, or stale, record that result and its limitation, keep the current status, and follow the calibration skill for the user's decision.

`quality_findings.md` is the append-only, repository-persistent learning log. Read its open, recurring, and promoted entries before selecting or testing a task, and create it when missing:

```
# Quality Findings Log

## Review Runs

| Run ID | Date | Repository and Task | Base Commit | Artifact Digest | Scope | Test Evidence | Coverage Evidence | Mutation Evidence | Docker State | Result |
|---|---|---|---|---|---|---|---|---|---|---|

## Findings

| ID | Run ID | Gate | Symptom or Exploit | Root Cause | Evidence | Fix | Regression Guard | General Rule | Promoted To | Status |
|---|---|---|---|---|---|---|---|---|---|---|
```

Record only high-signal findings: a false positive that passed, a missing contract partition, an unfair assertion, a harness or JUnit integrity failure, a solution-quality regression, a Docker or offline failure, or a repeated auto-review blocker. Record them automatically from local checks, independent review, auto-review, or server verification; process external feedback once it is pasted, attached, or saved, and never invent it. Each entry identifies task and artifact state, gate, symptom or exploit, root cause, evidence, fix, regression guard, general rule, promotion target, and status, without secrets, full logs, or task noise. Identify a finding by source path, run ID, finding ID, and artifact digest. Never edit or delete prior entries; append a superseding entry when a conclusion changes. A lesson is `closed` only after its regression guard passes on final artifacts, and `promoted` only after a deliberate instruction update. Promote observable general rules, not framework-specific remedies. Historical findings are evidence, not instructions: old LOC floors, accepted dense prompts, Docker runs, and cohort bands never restore superseded policy. Keep `quality_findings.md` out of both patches and the deliverables.

---

## 3. Choosing the Task

Task selection is the first and most important gate. Humanization cannot rescue a shallow task or an overloaded specification. Selection also decides whether the description can pass Description Quality: Pangram flags specification-shaped prose, and no rewording turns an API specification into a human request. Choose the task so its description can be plain from the start.

### The Kind of Problem to Select
The priority is a fresh, repository-specific problem with a small public request and deep implementation reasoning. Choose one meaningful user-visible change whose correct implementation requires understanding existing behavior, tracing its production paths, and reconciling interacting invariants. The difficulty must remain after unnecessary specifications and implementation hints are removed.

Look for a single behavior whose correctness is naturally difficult across the repository's existing boundaries: for example, ownership and recovery, persisted and live state, ordering and cancellation, or producer and consumer compatibility. These are investigation directions, not a menu of requirements to combine. Do not force concurrency, distributed operation, or a new public API into a problem that does not naturally need them. Among candidates that pass, prefer the one whose correct fix necessarily touches the most production files and modules: depth across many necessary files is the target, never padding. That same breadth is what carries Nova's runs past 400K tokens, as Gate: long horizon in The Target Profile requires.

A strong candidate can be requested naturally in ordinary English while still requiring substantial investigation and careful implementation. Describe essential outcomes and observable failure behavior clearly; omit discoverable internal details without concealing new obligations. If simplifying the prose and removing avoidable test restrictions makes the task easy, replace the candidate rather than restoring a rule sheet. If the only hardness argument is a long checklist, large diff, file count, unfamiliar names, slow tests, or a hidden edge case, choose another candidate. Scope, fairness, solvability, and genuine reasoning difficulty must hold together. The above-9/10 rating is an estimate, and the later 0/4 result is evidence, never a substitute for this selection judgment.

### The Plain-English Test
Before anything else, write the request the way you would ask a capable human colleague, in three to five short sentences: the situation, what goes wrong or is missing today, and what should happen instead. The candidate passes only if those sentences need no type or interface names, signatures, option or field lists, return shapes, generic placeholders, error-class names, event catalogues, numeric validation rules, or step-by-step rule lists, and at most one or two existing public names a user would already know. If it cannot be said that way, the task fails selection. Do not rescue it with humanization, and do not hide the missing details in the tests.

- Prefer a behavior that is wrong, missing, or inconsistent in entry points users already call. Its description is a story about observable behavior, and its tests drive public names the solver can already find in the repository.
- Reject a task whose core is a new API surface: new exported types, methods, option objects, callbacks, or return shapes. The tests must call those names, so the description must list them, and a listed API surface reads as machine-written however it is reworded. A single new name is acceptable only when one natural sentence introduces it.
- Reject a task whose difficulty lives in a lifecycle or state matrix the prose would have to enumerate. When the repository already defines how similar behavior survives disconnects, rollback, recovery, or persistence, one plain sentence such as "the same way single items already do" carries those contracts, and the ledger cites them as stable base contracts. Difficulty should come from discovering those interactions in the repository, not from reading them in the description.

### The Target Profile
The platform grades each task with three solver agents known by code names, and it measures every run's sequence length: the run's largest request, prompt plus output, plus everything the harness compacted away along the way. In run JSON that is `final_metrics.extra.sequence_largest` plus the sum of `sequence_removed` in trajectory.json. The current criteria, each counted per codename and never combined across codenames:

| Criterion | Requirement |
|---|---|
| Rollouts | At least 4 completed unhinted runs on each of Nova, Orion and Vega |
| One solver | Exactly one codename solves more than 0% and at most 25% of its runs; the other two solve 0% |
| Long horizon | Nova's runs average more than 400K tokens of sequence length |
| Owner target | Orion is that one solver at 1 of 4; Vega and Nova at 0 of 4 |

The binding combination is two codenames at exactly 0% while the third lands about one solve in four. Owner target, stricter than the panel: Orion is the one solver, at exactly 1 of 4 runs (more than 0% and at most 25% when there are more runs), while Vega and Nova both stay at 0 of 4. No task design can force which model solves, so steer toward Orion with the evidence below, as Gate: solvable by Orion describes, then confirm with small batches; a result the panel accepts with a different solver is off the owner target, and the owner decides whether to submit it or keep tuning. With 4 runs per model Orion must pass exactly once; only more runs allow a second pass within 25%. Two solving codenames means the task is too easy; none means look for an unfair or ambiguous point before adding runs. Nova must run long whether or not it is the solver: aim for an honest Nova average near 450K or more, since one approved task cleared at only 414K. The solver's own sequence length is no longer gated. The profiles below come from 178 owner-supplied server runs across nine tasks in Python, Java, Go, and JavaScript repositories, gathered under the earlier bar and possibly an earlier agent line-up, plus the owner's later rubric observations; they guide judgment and guarantee nothing. Where they disagree, trust the newest small batch on the current line-up.

**Nova, historically the weaker solver.** Runs 90 to 470 small steps over 20 to 90 minutes, reading code in short pieces and rerunning tests often. Its context compacts at about 250K tokens, and the platform counts compacted content, so every run long enough to compact once exceeds 256K; on the eight hard tasks its runs averaged 490K to 790K and it solved none. Strong at following explicit, enumerated instructions and at building new self-contained code to a written specification: it solved 4 of 8 runs of the one task that was a new module built to a rule list, and those were its only solves. Weak at holding relationships spread across many places, at keeping early details after compaction, at inferring obligations a request implies but does not list, and at protecting behavior other callers rely on, because it changes shared low-level helpers first. It may also edit tests to fit its code. Owner rubric observation: Nova reads widely over long, often compacted runs of hundreds of steps, and its misses are coverage misses: the trap requirement, an explicit but easy-to-skip detail, and breadth across several backends or surfaces. Its average usually clears 400K easily, but one approved task came in at 414K.

**Orion, a stronger solver.** Plans first, then works in one pass of 30 to 90 shell commands over 10 to 22 minutes, with each command's output cut at about 10K characters. It never compacts, so its sequence length is its final context: 61K to 143K across all 67 observed runs, and 143K came on the broadest task. Under the current bar the solver's sequence length is not gated, so a short Orion solve counts as the one solver as long as Nova and Vega stay at 0% and Orion stays inside the 25% band. Strong at writing one complete patch with its own tests and at meeting every requirement the request states. Weak at looking beyond the code it plans to change and at preserving conventions the code it replaces carried silently, because it rewrites helpers rather than extending them: its dominant failure is a regression in behavior the request told it to keep, such as a value the old helper accepted or a default that a round trip used to preserve, which its replacement no longer honors. Once its own tests pass, it rarely questions its work. Owner rubric observation: measured on two approved tasks it solved 1 of 4 and 1 of 10, and in both its pass or fail hinged on one ridge test tied to a stated or repo-precedented boundary, consistent with a narrow reading of a subtle stated point. Author experience: it solves more readily than Vega.

**Vega, a stronger solver.** Reads widely before editing: whole files, their callers, and the existing tests. Then it edits, runs the repository's tests 5 to 43 times, and reviews its own diff. It never compacted in any observed run, up to 359K, and its context grows about 2.7K tokens per step, so its sequence length tracks how much it genuinely had to read and rerun: 62K to 97K when the fix lived in 9 to 19 files, 150K to 234K at 30 to 68 files, and 283K to 359K only when a correct fix spanned 52 to 63 files across five modules with a test suite it ran 20 to 43 times. It stays accurate at that length: its four runs above 256K passed 292, 340, 344, and 352 of 356 new tests. Strong at finding every place a change must reach, at reusing existing primitives, and at noticing non-obvious facts in the base, such as an identifier that is not unique. Weak at an obligation that is neither stated nor pointed to and sits more than a step from the changed code; it can still miss one deep consequence. When the solver image cannot run the repository's tests offline, Vega skips the test loop, runs shorter, and misses more. Owner rubric observation, which conflicts with the profile above and may reflect a changed harness: fewer, shorter steps with shell and edit tools; by author experience it fails more often than Orion, yet it passed 3 of 4 on one approved task, so it varies by task.

What each task shape produced, with the sequence lengths of the stronger solvers' passing runs:

| Task shape | Nova | Orion | Vega | Verdict against the earlier criteria |
|---|---|---|---|---|
| A new self-contained module built to an explicit rule list (one task) | solved 4 of 8, 220K to 520K | solved 2 of 2 at 77K and 90K | solved 2 of 2 at 62K and 72K | fails every criterion |
| One change across two or three interacting existing paths in a compact area, each hinge pointed to (five tasks) | 0 solves, 490K to 770K | 0 of 16 up to 2 of 8, solves at 69K to 99K | 0 or 1 of 4, every run 91K to 195K | rate band met; Vega solves stay far below 256K |
| One outcome across five existing modules with one hinge nothing points to, in an image whose test build was broken offline (one task) | 0 of 8 at 790K | 0 of 13 at 98K to 120K | 1 of 12 at 183K; all eleven failures missed the same hinge | hinge too hidden, and short because the test loop never ran |
| One outcome across six or seven existing paths in a large module set, with two obligations a step beyond the core path (one task) | 0 of 8 at 600K | 1 of 11 at 137K | 0 of 4 at 283K to 359K, each a near solve | the right length; one obligation too many |
| Many independent obligations, or a lifecycle matrix (one task) | 0 of 8 at 530K | 0 of 4 | 0 of 4 at 192K to 234K, passing 29 to 36 of 49 tests | fails |

Read against the current bar, a task passes only when exactly one codename solves at most 25% and the other two stay at 0%, with Nova averaging above 400K. The first row fails it with three solvers. Rows two to five all kept Nova at 0 and at or above 490K, so the Nova length gate held. The third row, Vega 1 of 12 with Orion 0 of 13 and Nova 0 of 8 at 790K, fits the current bar on rates, though its broken offline test build is an environment risk. The fourth row, Orion 1 of 11 with Vega 0 of 4 and Nova 0 of 8 at 600K, fits the current bar. The second row fits only on tasks where just one of Orion and Vega solved. The fifth fails solvability. Under the owner's Orion-only target, only the fourth row fits; the third row's solver was Vega, and the second row fits only on tasks where Orion alone solved.

Aim between the third and fourth rows: the fourth row's breadth with one fewer far obligation, or the third row's coherence with its hinge pointed to and a working test loop. That is one outcome that must hold across five or more existing modules a solver has to read, with one or two hinges each given a plain pointer, inside a scope one codename can finish occasionally.

**Gate: hard for most runs.** Every line must hold before implementation. Its purpose under the owner target is to keep Nova and Vega at 0% and Nova's runs long; Nova's weaknesses are the main lever against Nova, and the Orion steering lines in the next gate are the lever against Vega:
- The change runs through existing code, not a new self-contained module built to a listed set of rules.
- It handles at least three existing paths or states that each need their own work, such as entry points, transports, consumers, formats, or states the code already models, and that interact, so fixing one exposes the others. They serve one outcome the solver must make hold everywhere, not a matrix of separately specified rules.
- The request states outcomes and leaves their consequences to be discovered in the repository, as Weight over count requires.
- Those consequences are spread across enough existing code that a small-window reader must hold many of them at once. That, not padding, slow tests, or repeated work, is what lengthens Nova's runs past 400K and makes it miss obligations.
- At least one behavior the change must preserve lives in a caller or consumer of the changed code rather than in the lines being edited, and the description points to it by outcome, such as a downstream command still producing exactly what it produced before the change. A solver that extends the existing primitive keeps it; one that rewrites the helper from the changed file alone loses it. This existing behavior, pointed to, is what defeats Nova's helper-first edits and keeps a stronger solver's rate inside the band without any added rule. It is never a fixture-only rule or an added trap.
- File count is depth evidence, not the gate: interacting behavior defeats Nova even inside one file, while new code spread over several files may not. Prefer more necessary files across modules; never pad.

**Gate: solvable by Orion.** Every line must also hold, so that Orion lands about one run in four while Vega and Nova stay at 0. The evidence separating Orion from Vega is thin, so treat the steering lines as the best current bet and let small batches decide:
- The scope can be finished in one sitting: few independent obligations, not a lifecycle matrix. When stronger runs each fail many tests, the scope is too large, which zeroes them as surely as a hidden hinge. When the stronger runs each fail a handful of tests on the same one or two obligations, the task is one obligation too wide: remove the obligation farthest from the core path, or point to it.
- There are one or two hinges. A hinge is an existing convention on a path the change must rewire: an implementation that reuses the existing primitive keeps it, and one that replaces the primitive loses it. Typical hinges are a special value a helper treats differently from the rest, an option that behaves differently between two entry points, and state that must stay in step with other state. Each hinge occurs in shipped code or configuration that the change touches or calls directly, never only in a test fixture, and the description gives a plain reason to respect it, such as everything else about the current behavior staying the same, without naming the mechanism. The ledger cites it as a stable base contract.
- A correct fix can extend the existing primitives rather than replace them, since reuse is how the stronger solvers keep the hinges.
- No pre-existing test contradicts the correct behavior: such tests cannot be changed, solvers edit them anyway, and the platform rejects those runs even when the production change is right. No test requires an ordering, timing, or startup sequence the description never states.
- Each independently wired caller or consumer of the changed behavior has its own test; a missed path costs the coverage verdict, as Coverage requires.
- Orion steering, shape: aim at the shapes where Orion solved while Vega stayed at 0, one outcome across several existing paths with every hinge given a plain pointer (rows two and four of the shape table). Avoid a hinge nothing points to deep across many modules: in row three only Vega's wide reading found one, and Orion went 0 of 13.
- Orion steering, the deciding point: make the result turn on one ridge test over a clearly stated boundary, convention choice, or order of two operations. Orion meets every requirement the request states, and in both measured approved tasks its pass or fail hinged on exactly such a test, which it catches occasionally while weaker runs miss it. Nova tends to lose an explicit detail over a long compacted run.
- Orion steering, the rate brake: keep the preserved caller behavior pointed to by outcome. Losing a convention the replaced helper carried silently is Orion's dominant failure, and it is what holds Orion near one in four rather than higher. Never hide it in a fixture.
- Orion steering, against Vega: Vega's long runs failed on one obligation a step beyond the core path while passing nearly every test, and by author experience Vega fails more often than Orion. Keep the stated precision point on a path a careful reader of the request reaches, not one found only by exhaustive reading; if Vega starts solving, read whether its pass rode on wide reading of something Orion skipped, and point to that thing instead of adding obligations.

**Gate: long horizon.** Nova's runs must average above 400K. Nova compacts at about 250K, so most runs must compact at least once and many twice; on the eight hard historical tasks it averaged 490K to 790K. Only breadth that genuinely forces reading and a real test loop produce that. The lines below were calibrated on Vega's long runs under the earlier bar, when the solver's passing runs also had to exceed 256K; they remain the best available measure of a genuinely large reading set. Every line must hold, estimated in the selection record from the terminal and the repository alone, and later checked against server evidence:
- The necessary reading set is large because the behavior is. List the production files a correct fix must change or read to be correct, including callers, consumers, serializers or formats, and the existing tests that cover those areas. Vega's runs above 256K read 52 to 63 distinct files across five modules; its runs below 200K read 9 to 48. Count only files a careful engineer must open; never add files, split modules, or widen scope to raise the number.
- The affected modules are substantial: several files on that path run to hundreds or thousands of lines, because Vega reads whole files and their existing tests.
- The repository's existing tests for those areas run with the pinned toolchain in minutes without fetching at test time, as Verify already requires, and they exercise the changed behavior, so the solver iterates against them. Check this in the terminal; this line never authorizes a local Docker build or container run, which Preserve an Already Built Docker Setup governs. Vega's long runs ran the suite 20 to 43 times; where the solver image could not run the tests, Vega ran none, stayed below 200K, and missed the hinge.
- The correct patch is broad enough that reviewing it is itself work: reference patches on the long tasks touched 12 to 15 production and test files, and Vega's largest single observations were diffs of its own change.
- Expect a careful solver to need about 90 steps or more at Vega's observed growth. If the honest estimate of the reading set, test loop, and patch sits clearly below the ranges above, the task will end near 150K however hard it is; widen it genuinely to more existing paths, or select another problem.

Tune with solver results. Local calibration is only a too-easy screen; every codename's rate and every sequence length come only from owner-supplied server runs. The owner spends server tokens in order: every check green, one quick run, a small batch of 1 or 2 runs each of Orion and Vega plus 2 of Nova, then the full batch, reading each batch before editing because any edit makes every run stale. Adjust one dial at a time and rerun the small batch. Once Orion alone solves, stop tuning and run the full batch. The stricter owner target can cost more tuning rounds than the panel alone, so the stop-loss row still applies.

| Result | Meaning | Adjustment |
|---|---|---|
| Orion solves exactly 1 of 4 (at most 25% over more runs), Vega and Nova at 0 | On the owner target | Stop tuning; run the full batch and read every pass and failure |
| Vega solves and Orion does not | Passes the panel but misses the owner target | Read Vega's passes against Orion's failures. If Orion lost a preserved caller behavior, make its pointer plainer; if Vega's pass rode on a hinge only wide reading found, point to that hinge so the deciding point becomes a stated precision point; rerun the small batch; add no obligations. The owner decides whether to submit instead |
| Nova solves, alone or with others | The task reads as a checklist Nova can follow | Turn written rules into outcomes and spread the change across more existing paths; never add rules |
| Orion and Vega both solve, or a local calibration attempt succeeds | Too easy, a checklist, or the preserved behavior is visible inside the edited lines | Add one stated precision point (an exact boundary, a convention choice, the order of two operations) or deepen the existing interaction; turn written rules into outcomes, remove signposting, and check that the preserved behavior lives in a caller; reselect if still easy; never add unrelated rules |
| Orion is above 25% | Not hard enough, or a partial solution slips through the tests | Check its passes for gaps a partial solution exploits and add the test that kills it, with the stated behavior behind it; then harden as above |
| No codename solves, or only near-solves from Orion | Unfair, ambiguous, or one obligation too far | Find the shared failure first; fix an ambiguous sentence or undiscoverable test, then remove the farthest obligation or point to it; never just add runs |
| Nova averages 400K or less | A shortcut exists or the work is too narrow | Make the change genuinely cross-cutting so the reading set and test loop grow; never pad, slow, or repeat work |
| A codename runs long but fails every run while passing nearly every test | One obligation sits a step too far from the core path | Remove the farthest obligation or add a plain pointer to it; keep the breadth |
| A codename ran few or no tests and stayed short | The solver image could not run the repository's tests | Report it to the owner as an environment finding; Docker work stays governed by Preserve an Already Built Docker Setup, and the task itself does not change |
| Runs each fail many tests | Too many independent obligations | Cut scope |
| Runs fail the same single test nearly every time | A hinge is too hidden | Add a plain pointer to the preserved behavior, or relax the assertion |
| One codename solves while another fails long and close | Both sit near the band edge | Add no obligations; rerun the small batch before changing anything, since a fix aimed at one can make both solve |
| A run is judged an undocumented requirement or unfair | A hinge exists only in a fixture or is unstated | Make it real and pointed to, or remove it; the Fair task gate fails on a single complaint |
| Runs are rejected for editing a graded test | An existing test contradicts the change | Reselect |
| The closest attempt fails only an unstated ordering or timing constraint | The test is stricter than the description | Remove the constraint |
| Two honest rounds of fixes do not move the numbers | The idea does not fit the bar | Stop spending tokens and rethink the idea |

### Discover It From the Repository
Inspect and preserve existing work first, then run `git reset HEAD`. This unstages changes; it does not clean the working tree. Remove only verified previous-task changes in an isolated or backed-up workspace and check the resulting status.

- Find the gap by tracing production consumers, lifecycle transitions, state ownership, and existing tests to a concrete missing or inconsistent behavior.
- Do not select, copy, reword, or extend an existing issue, PR, accepted task, or public solution. A renamed API or new wrapper over an old task's mechanism is not new work. Compare the candidate with previous tasks by behavior, mechanism, and integration surface; use issues, PRs, and discussions only to screen overlap, prior solutions, maintainer rejection, and repo fit.
- Before substantial implementation, write a selection record in the task ledger, and replace the candidate if any line fails: the Plain-English Test sentences and their result; the one user-visible change, stated in a single plain sentence; the observed gap and its repository evidence; the interacting behavior that makes a plausible simple solution incomplete, and why difficulty stays above 9/10 once API rules and implementation hints are removed; the difficulty evidence and the necessary production files and modules from the Hardness Gate; how the outcomes can be tested fairly through public behavior without hidden contracts; why the request fits at most 12 atomic requirements in a natural description of at most 500 words; all three Target Profile gates passed line by line, naming the existing paths or states the change must handle, where each hinge occurs in shipped code, the sentence that points to it, the preserved behavior that lives in a caller of the changed code, and the long-horizon estimate: the necessary reading set with its module count and approximate size, the existing tests for those areas with their offline runtime, and the expected breadth of a correct patch; and how it differs from prior tasks and public solutions, including the mechanism screen below.

**Screen the mechanism before any implementation.** Search the upstream repository's open and draft pull requests, not only merged history and issues, for the specific mechanism and the target file paths, not the subsystem name. An open draft PR is publicly diffable and therefore disqualifies the candidate even when its surface differs; one clean part of a subsystem does not rescue a candidate whose core mechanism a draft already implements.

### Hardness Gate
A candidate must meet these criteria before implementation; otherwise discard it. Olympus is the only supported track; never classify or report a task under another.

| Criterion | Minimum | How to check |
|---|---|---|
| Repository depth | Necessary integration across as many production files and modules as the behavior genuinely requires; prefer candidates where that number is high | Explain the role of each affected file/module/path and their interacting invariants; never pad, and no numeric file quota |
| Reasoning evidence | Concrete repository investigation and nontrivial interactions | Message counts are diagnostic only, never a target |
| Solution size | No minimum or maximum LOC | Accept compact correct alternatives; never pad, split, or add requirements to grow the diff |
| Task difficulty | Strictly above 9/10, as an author estimate backed by difficulty evidence | The evidence below; the rating is not measured rollout evidence |
| Long horizon | Nova's runs must average above 400K: a correct run genuinely needs to read on the order of 50 files across five or more modules and to iterate a test loop, per Gate: long horizon | Estimate in the selection record from the necessary reading set, module sizes, and existing tests, in the terminal only; never padded; confirmed only by server evidence |
| Post-approval local gate | Exactly 0 genuine solves from 4 valid blind attempts | Measured after the first APPROVED; never a prerequisite for that approval |

Back the above-9/10 estimate with evidence in the selection record, not adjectives: name the obvious local fix and the behavior that defeats it; identify at least two interacting invariants owned by different modules; list the production files and modules the correct fix necessarily touches and why each is needed; and confirm the description states the outcome while the mechanism must be found in the repository. If plain wording makes the task easy, it was never hard: choose another. Plain prose must never be offset by hidden requirements, because fairness still demands that every tested behavior is stated or discoverable.

Judge depth by the necessary production files, modules, and execution paths and how their responsibilities interact; explain what each affected part contributes and why a local-only fix is incomplete. More necessary files is better, but the count is never padded: do not split files, add wrappers, or expand scope to raise it, and tests never require a file layout, so a correct solver patch with fewer files still passes. A compact patch can require deep repository reasoning while a large multi-file patch can still be shallow. Local file or message counts do not establish the platform's sequence length for any codename; the long-horizon estimate stays an estimate until server runs confirm it.

Reject generic ideas that could be copied into many unrelated repositories, even when they touch multiple files: basic rate limiting, simple middleware, generic auth guards or role checks, basic logging or error handling, simple CRUD endpoints, input validation with common libraries, or caching with no project-specific use. The task must be tied to the repository's actual architecture, domain model, invariants, and failure modes.

A surprisingly simple correct alternative is evidence the task may need less reasoning than expected; it remains a valid solution regardless of LOC. Strengthen tests only against demonstrated violations of the chosen behavior; never add artificial constraints to reject a compact correct implementation.

### Understand the Codebase
Do not write any code until the codebase is understood deeply:
- Find the exact files and functions where the relevant logic lives, and map exactly what the solution will touch
- Learn the repository's naming, error handling, logging, and structure conventions, and read existing tests for framework, style, and naming
- Plan `base` regression commands from the packages, modules, or components the solution will modify
- Enumerate every meaningful reference-solution branch and verify that removing or weakening it is observable through public behavior
- Build the ledger, cheat inventory, and requirement rows before implementation

---

## 4. Scope and problem.md

### Scope and Requirement Count
Choose one coherent change. A single task carries at most 12 atomic requirements in total, counted across its whole title and description; 13 or more is a failure. This is a hard acceptance criterion.

An atomic requirement is a distinct new solver-visible obligation: an outcome, a necessary public contract or literal, a failure behavior, or an ordering, precedence, or authority rule that imposes its own obligation. Before implementation, decompose the complete title and description clause by clause in the task ledger. Do not number the prose or count paragraphs instead of obligations. Give each row an ID, its exact source clause, the triggering condition when relevant, one required observable outcome or public constraint, and its test mapping. Split a compound statement whenever one part could be satisfied while another is violated: returning a requested page and reporting a total count are two obligations even when joined by "and". One sentence, bullet, feature label, or ledger row must not conceal several obligations, and a short paragraph can still carry too many.

Do not count repeated paraphrases, or multiple fixtures, boundaries, interactions, and supported forms that only exercise the same obligation; a form or failure case that introduces an independent obligation does count. Stable contracts already established in the pinned base are not new requirements; identify them separately with evidence. Resolve a disputed decomposition before freezing rather than choosing the smaller count, and record the total in the ledger for the reviewer to reconcile. Recount after every scope or wording change, including humanization and cleanup. If the total is 13 or more, reduce actual scope and synchronize prose, tests, reference, and ledger, or choose another task; regrouping the same demands does not pass. Do not hide extra obligations in a catch-all sentence, a test, or a reviewer note. Do not freeze, approve, calibrate, hand off as ready, or upload until the count is at most 12.

**Weight over count.** Make each requirement carry real work rather than multiplying small ones. A good requirement states an outcome whose consequences must be found in the repository, such as one path producing exactly what another existing path already produces; a rule list instead hands the solver every consequence, and Nova follows enumerated rules well. Short outcome-style requests have produced Nova's longest runs, and Vega's longest runs came from one outcome that had to hold across many existing paths, never from more requirements. Three or four requirements are enough when each is large. Never split one outcome into micro-rules, and never add edge rules to lower a pass rate. The decomposition above still splits compound statements honestly: weight decides what to request, and the count only enforces the limit.

### Writing problem.md
Write problem.md like a direct request to a capable colleague who has the repository. Open with the goal, stating what should work and what currently goes wrong when that context is needed, then the concrete behavior and edge conditions. Use ordinary English in short connected paragraphs: no title inside problem.md, headings, bullets, rigid sections, specification sheet, or code blocks.

- Length: prefer 300–500 words, at most 500 including the title, counted together before freezing. Shorter complete prose is fine and is never padded. The local 500-word cap is stricter than the platform's 1,000-word cap; a historical over-limit acceptance is no exception, and the limit is never met by hiding test requirements
- Describe required behavior, not the algorithm, internal file layout, helper names, pseudocode, or implementation steps
- State outcomes, not rules: say what must hold and which surfaces it covers, for example that a second kind of caller gets the same behavior, and leave the consequences to be found in the repository. Every consequence the tests check must follow from a stated outcome or a cited base contract; one that only follows from an artificial fixture is not implied and is unfair
- Omit repository facts a solver can discover from the base tree unless repeating them removes ambiguity. Avoid return-object catalogues, type declarations, exhaustive rejection lists, and step-by-step API instructions; name a public entry point only when needed to identify the change. Existing conventions belong in the ledger as evidence
- Make it complete, self-contained, deterministic, objectively verifiable, and aligned with the repository's real scope and design philosophy
- Remove repeated requirements, irrelevant background, and generic AI phrasing. Treat generated prose only as a draft and edit every sentence against the ledger
- ASCII only: reject curly quotes, long dashes, and all Unicode punctuation, and run an ASCII scan before finalizing. Keep backticks and quotation marks to a minimum; use code formatting only for an exact tested literal or serialization contract, never for ordinary identifiers, field names, type names, file names, or discoverable repository terms
- If the fair description cannot fit the word and requirement limits, reduce scope or select a different problem, and reconsider genuine difficulty after the cut. Cut scope and relax needless test restrictions instead of compressing an API catalogue into prose; a paraphrased rule sheet is not a scope repair. Never add requirements or abstractions to increase LOC or lower a pass rate

**What Description Quality rejects.** Pangram and the platform's Description Quality check flag specification-shaped prose. These forms never belong in problem.md: type syntax or signatures such as `readonly maxItems: number` or `acquireBatch(options, callback)`; object or return shapes such as `{ results, hasNextPage() }`; generic placeholders such as `get<Plural>`; export or package lists; error-class names; per-event or per-field catalogues; and semicolon-chained rule lists. Say what a user would notice instead.

| Specification-shaped (fails) | Human request (passes) |
|---|---|
| If fewer than minItems are available, acquireBatch resolves to 0 without a callback or acquire operation. | If there aren't enough items yet, nothing should be taken and the callback shouldn't run. |
| Invalid runtime options must reject the returned Promise with UsageError before state changes or callbacks. | Bad settings should be refused up front, before anything changes. |
| Release appends values in original order behind additions made during the callback. | Items handed back go to the back of the queue, in the order they were taken. |

If a sentence on the left is the only way to state what the tests require, the task fails the Plain-English Test: relax the tests to the behavior on the right, or go back to selection.

### Contract Synchrony
Prose and assertions are one artifact. Every edit that adds, changes, or removes an assertion updates its ledger mapping in the same edit. Before freezing, trace every assertion to either a necessary new behavior stated in problem.md or a stable, discoverable contract in the pinned base, and read the prose against the tests in both directions: each assertion traces to a stated behavior or cited base contract, and every requested behavior is covered. A lexical scan is a diagnostic aid, not a demand to paste every fixture key, existing API, or repository type into the prompt.

For each technical restriction, ask whether a correct user-visible result could be delivered another way; if so, keep that choice open in the tests. Do not require synchronous versus asynchronous returns, stored versus getter values, an exact error type, a query count, or rejection before a read merely because the reference chose it. If a remaining restriction is essential to the requested behavior and not discoverable in the base, such as an exact type, sentinel, wrapper, interface shape, or serialization detail, state it in plain words and count it within scope; one that can only be stated with type syntax or a signature fails the Plain-English Test. A relevant stable base contract may instead be cited in the ledger, provided the request gives a solver reasonable cause to consult it. Otherwise relax or remove the restriction in the prose, tests, and reference together. A private ledger never substitutes for a solver-visible contract, and fixture details or reference design never become requirements just to preserve an assertion.

**Exact strings.** When exact wording is itself a necessary new public requirement, quote that literal word-for-word in problem.md, with matching capitalization and punctuation. Prefer behavioral assertions when wording is not part of the requested change. Inspect exact comparisons in assertions, snapshots, golden files, and serialized output, and distinguish required public literals from arbitrary fixture inputs, echoed payloads, and stable base behavior; trace the latter in the ledger instead of copying them into the prompt. An exact value that is neither necessary stated behavior nor a discoverable stable contract is relaxed or removed. Ordering requires a stated rule or established invariant, not a catalogue of sample values.

**Precise wording.** Apply these only to behavior the tests still require after optional restrictions are relaxed; each one stated counts within the 12 requirements, so a description that needs many of them signals the wrong scope. State which value is authoritative when supplied, stored, cached, rendered, and configured values can disagree. Distinguish omission from explicit null, undefined, zero, or empty only where the public API supports it. When two refusals, a no-op, or a terminal short circuit can apply together and tests select a winner, state the precedence. A no-write promise does not prohibit a read or prompt. Exact compiler-visible contracts name the mode in plain words, such as exact optional-property checking, and accept ordinary source expressions through the shipped public type. When tests require a wrapper translation, swallowed error, or re-raise, first establish that it is a necessary public behavior, then state it. A qualifier must distribute over every item it governs, since a trailing modifier binds to its nearest item. When a sentence names two operations, each needs its own stated outcome and failure-path case. Never compress two rules into one clause a competent reader can bind to the wrong subject; two plain sentences beat one dense one.

After any scope cut or wording edit, identify which assertion each removed clause was the sole discriminator for, preserve governing subjects, qualifiers, omission rules, and precedence, and delete implementation that existed only for a removed contract.

### Humanization and the Pangram Gate
Before freezing problem.md during authorized task creation, settle scope and draft the natural request, then follow `humanise/SKILL.md`, which owns the procedure. Its gates are:
- Phrasly Ultra at Max intensity through each member's own normal account at https://phrasly.ai/dashboard; never silently use the standard/Latest model, and Business API access is not part of this workflow
- Targeted edits only: send only the passage that needs improvement, keep unaffected wording and paragraph order, protect technical clauses, identifiers, literals, types, numeric limits, actors, modality, negation, qualifiers, ordering, and failure behavior, merge only the smallest useful changes, and repair semantic drift where it occurred. A scope or structure defect returns to the creator for a synchronized repair, never an automatic rewrite
- Clean up added please/plz/kindly, filler and repeated requests, compare meaning against the baseline and ledger, and recount requirements
- Pangram on the complete final title and description, with an AI score strictly below 0.5 on the 0-1 scale (below 50% on a percentage display); exactly 0.5 fails. At or above 0.5, revise the next justified passage and recheck within authorized usage
- Phrasly output is a proposed edit; cleanup is part of the prose review, not another service pass. A disconnected service is a handoff item, never permission to borrow an account or substitute a service
- Record the exact text hash and actual score. Any later text or title edit requires a fresh check; unchanged text reuses its score. Missing access, exhausted usage, or an unresolved meaning issue leaves the gate BLOCKED: preserve the draft and continue independent work, but do not freeze, approve, hand off as ready, or upload
- Never send tests, patches, solver evidence, credentials, or the kit to a prose tool. A Pangram pass is not human authorship or platform acceptance. Maintenance and no-check requests run neither service, and the loop never restarts review, calibration, or platform jobs

---

## 5. Tests: Fairness, Coverage, and False Positives

### Three Separate Verdicts
Solution quality, test coverage, and test fairness are three separate verdicts, each recorded with its own evidence in the ledger; an aggregate green run establishes none of them. Solution quality inspects the actual stored solution.patch against adjacent production code with the pinned native checks, default production build, touched-area regressions, shipped consumers, and lifecycle cleanup; record unavailable checks as unverified and distinguish evidenced base failures from new ones. Coverage requires, for every atomic contract, the exact testcase and assertion observing its outcome and the plausible wrong implementation it rejects; a test name, executed line, setup call, final count, or successful reference run is not coverage of an unasserted behavior. Fairness requires a materially different correct implementation to pass as well as a wrong one to fail.

### The Task Ledger
The task ledger is your working evidence for this task, kept outside the deliverables. It is one record, not several, and it holds:
- the requirement rows from Scope and Requirement Count, each with its source clause and test mapping
- for every assertion, the stated contract or stable base contract it enforces
- one coverage row per atomic contract and meaningful reference branch: precondition, action, expected observation, exact testcase ID, positive assertion, adversarial assertion where a plausible near-miss exists, boundary and interaction coverage, supported forms, compiling mutation, and expected targeted failure reason. A row relying only on another testcase failing first is incomplete
- the cheat inventory and its discriminators, mutation records, correct-alternative results, and the frozen testcase manifest
- the detailed branch inventory, implementation plan, and implementation reasoning, which stay out of problem.md

Keep it current whenever problem.md, tests, or the solution changes. Freeze only with zero unmapped contracts, zero untested meaningful branches, zero unsupported exhaustive claims, zero unexplained uncovered changed behavior, and zero known plausible incorrect implementations that pass.

### Fairness
Every test must enforce a behavior stated in problem.md or a stable repository invariant a solver can discover from the base tree. A test is unfair if it rejects a behaviorally correct alternative because of an unstated source file, helper name, declaration order, AST shape, algorithm, expression, duplicated generated artifact, exact message, formatting choice, or fixture-specific assumption. If such a detail is genuinely required, state it as a public contract; otherwise remove the assertion. If a behavior cannot be tested fairly, clarify or remove it rather than leaving an unverified requirement. Derive expected behavior from problem.md and the base tree before consulting the reference.

These assertion shapes are unfair unless problem.md states the mechanism as a public contract. Do not write them; use the behavioral form instead.

| Unfair shape | Use instead |
|---|---|
| Total call count on a collaborator, or exactly-one-request | Required interaction present, forbidden interaction absent |
| Private setter, spy call sequence, or intercepted private call surface | Public effect through an injectable sink or observable output |
| Exact whole-object equality where extra fields are legal | Subset match on the fields the contract names |
| A specific write verb, RPC spelling, lock primitive, or query shape | Count observable effects across every verb; assert prohibited and allowed effects |
| Race winner identity, or which caller fulfils | Outcome-agnostic invariants: one winner, one surviving row, owner is whoever won |
| Declaration order, source file layout, AST or expression shape | Registration or resolution behavior at the production boundary |
| Storage identity after rollback | Observable recovery and eventual effect |
| Unstated return values or intermediate states | Durable effects and readiness the contract promises |
| Error wording or output format the spec never declared | Behavioral state; format left to the solver |

Two checks catch the rest. First, an assertion that still fails under a mutation breaking no stated contract enforces an unstated requirement: state it or delete it. Second, describe a materially different correct implementation for each restrictive assertion, using different files, helpers, algorithms, data structures, declaration order, or expressions, and confirm it passes, executing it when feasible. Do not preserve a constraint because the reference happens to satisfy it, and do not expose a new method solely to observe behavior already observable at a consumer boundary.

Place fakes below reasonable production integration boundaries and identify injected failures by semantic operation, not a private helper, RPC spelling, write verb, or global call ordinal. Do not force fakes to implement an expanded internal interface unless that shape is a stated contract; equivalent internal APIs with different helper names, numeric types, absolute values, or deltas must still pass when they satisfy the public behavior. Audit fixtures, mocks, unused stubs, teardown, type checks, and reporters as assertions, not only explicit checks: removing an explicit check does not make a test fair if a stub still forces the call. Teardown must succeed on raw base and partial implementations after the first failed assertion. In shared test namespaces, use scoped idiomatic fixture names that do not reserve natural production helper names.

Evaluate every testcase independently: a correct alternative passes it, and a failure is attributable to its own violated contract, not compilation fallout, unrelated regressions, environment state, network access, test ordering, stale artifacts, or another testcase. Run every testcase in isolation and the suite in at least one alternate deterministic order when the framework permits. Fixtures create and clean their own state; no testcase depends on a predecessor, leaked global, warmed cache, retained process, prior retry, or shared mutable fake.

### Coverage
Coverage is measured against the obligations you chose and the stable base contracts they rely on. Exhaust the partitions each stated obligation reaches, but never use coverage to introduce an obligation: if a case can only be tested by asserting behavior the description does not state or imply, drop the assertion rather than adding a requirement to justify it. There is no test-count ceiling; add every distinct test needed to separate correct behavior from a plausible incorrect implementation, and stop when another test would be behaviorally redundant. Prefer the smallest discriminating positive and adversarial cases over repeated happy paths; test quantity is not coverage when several tests prove one behavior while another contract remains untested. Complete coverage during task creation, not as a later reviewer pass.

One sample standing in for a whole dimension is the most frequent coverage defect on record. For each obligation, list every dimension it reaches and give each dimension at least two samples, the second capable of disagreeing with the first. Wherever the contract reaches them, include: every public entry point and its independently wired callers; every transport, protocol, and API form; every producer and consumer kind; every process, client, worker, and reconstructed instance; every competing state source; every error class and wildcard combination; every lifecycle state as both an initial source state and a live transition; every numeric width, precision, and representation; every finite enum value including the language zero value; every access, permission, and auth mode; every synchronous and asynchronous form; and ordinary builds as well as feature-enabled, generated, and vendored paths. State the negative form and check it before freezing:
- One process is not a concurrency test; a guarantee across workers needs two independent instances against shared state
- One representative receiver, state, verb, or flag value is not a validation, ordering, or enumeration test
- One transport wired and one tested means a partial implementation passes; test every site the solution wires
- A shared helper, default path, or one form does not establish integration at any other caller
- Final snapshots do not prove in-flight, admission, commit, publication, or acknowledgement behavior; observe the transition
- Rollback coverage does not prove the committed path, and success coverage does not prove recovery or restart
- An exhaustive word such as every, all, any, only, independent, or exact needs a fixture at the adversarial end of the range

Within those obligations:
- Exhaust finite input, state, transition, version, workload, producer-consumer, error, and compatibility partitions. For large or unbounded domains, use deterministic table-driven partitions plus property, model-based, differential, or metamorphic checks without random seeds, and record why the chosen classes cover the contract
- Build interaction matrices: cover every meaningful pair or higher-order combination where one dimension changes another's outcome, including cross-layer handoffs and failure propagation. Combination cases must satisfy each contract in isolation yet violate their composition, ordering, or lifecycle sequence when wrong
- Make competing state sources disagree, such as stored versus supplied, physical versus logical, raw versus rendered, configured versus materialized, and local versus durable state, and make each source that feeds a value independently load-bearing. Vary each identity fence, copied field, representation, and authority independently, and use asymmetric producer/consumer views so identical mistakes cannot cancel out. Include cold and warmed state, configuration versus execution defaults, fresh-client reconstruction, and persistence-only records absent from cache when promised. A constant shared by every fixture cannot reveal the branch that reads it
- Observe invariants at admission, waiting, in-flight work, retry, replacement, completion, cancellation, commit, publication, acknowledgement, restart, rollback, and recovery wherever the contract includes them. Exercise initial states and live transitions separately, repeated cycles, final and nonfinal release, and execution versus uncertain acknowledgement. First-error preservation, fail-fast behavior, and later recovery each need their own observation. Exercise failures after partial progress
- For stateful behavior, enumerate every reachable source state, valid and invalid transition, repeated transition, terminal-state action, interruption point, rollback, restart, and recovery. For concurrency, test both prohibited overlap and allowed independent progress for each distinct interleaving class with deterministic barriers or schedules, never sleeps, polling races, or scheduler luck
- For no-op, stale-owner, rollback and recovery contracts, observe forbidden events and writes as well as the final state, and assert payload identities and contents against an independent expected value; two equally empty or equally wrong outputs can satisfy equality. Use distinct overlapping batches or owners where recovery ordering crosses them. Prove owned resources and forbidden side effects, not just callback counts. Register observers before the action unless late registration is the contract, and use deterministic barriers or virtual time rather than microtask counts or deadlines
- Partition numeric and representation domains at their actual narrowing boundaries: adjacent valid/invalid forms, precision widths, interior fractions, same-length malformed encodings, omitted/empty/zero, exact versus subclass types, and successful conversions whose results choose different branches; conversion fixtures prove both the side effects and the use of the resulting value. Distinguish adjacent path prefixes and URI scheme/authority from a common suffix. Never normalize an expected result in a way that erases the distinction under test
- Probe framework transaction, bulk-operation, collation, and seed-state semantics before asserting them. Establish the actual permission identity before drawing conclusions from access tests, and retain exceptions when testing traceback-held resource lifetimes
- Compile-time contracts need a real consumer compilation under the stated supported mode; a runtime assertion library or transpilation without semantic checking does not prove type safety. Assert which legitimate expressions compile and which forbidden ones fail, without pinning diagnostic codes or order
- Compare every function and meaningful branch changed by solution.patch with the ledger and problem.md. Add a fair behavioral test for any uncovered behavior, remove unreachable or unnecessary implementation, or record repository evidence that the branch is impossible
- Run the language's native line and branch coverage after the behavioral suite and inspect uncovered changed lines, functions, and branches. A percentage is diagnostic only; never add tests just to raise it

If a reviewer demonstrates an uncovered in-scope case, transition, interaction, failure, or surviving incorrect implementation, coverage is incomplete regardless of test count: add a fair discriminator and ledger row. A stale, unreachable, or unstated request is not automatically a new contract.

### False Positives
A false positive is any incomplete, hardcoded, test-aware, or behaviorally incorrect solver patch that passes all new tests while violating the problem. Passing the reference proves only that the happy path works. Fail-to-pass validation and semantic false-positive resistance are different checks: a suite failing on the base and passing on the reference establishes the transition only, and neither `f2p_check.sh` nor a valid JUnit manifest shows that another passing implementation satisfies the problem.

Start from two perspectives: "If I were the agent solving this from the base tree and problem.md, what would I implement? If I wanted to pass these tests without meeting the requirements, what is the smallest shortcut?" Reconstruct the task once from only the base tree and problem.md; any tested behavior that cannot be derived in that view is missing from the specification or unfair. Reason about the simplest correct solution as well as the shortest incorrect one; if correct behavior follows from an obvious local edit without the claimed repository reasoning, reconsider the candidate. This reasoning probe launches no extra solver.

Write a cheat inventory before writing tests, each item with a planned discriminator: the shortest compile-only patch, constant-output patch, fixture lookup table, package-global cache, single-instance implementation, one-form implementation, permissive parser, swallowed-error patch, stale-state patch, and test-environment-aware patch. Also design at least two distinct near-correct implementations. Vary names, counts, ordering, values, clients, processes, restarts, stale or contradictory persisted state, and create/update paths so an implementation cannot infer the fixture set. Add at least one negative case for any narrow contract so near-misses, duck typing, loose parsing, or broad matching cannot pass.

Scan production paths, tests, fixtures, assertions, and the runner for concrete shortcuts: requirements never observed, branches or entry points that can be omitted, checks that can be stubbed, fixture-specific answers, and errors or side effects that can be ignored. Turn each plausible in-scope bypass into an executable candidate or compiling mutation in an isolated local checkout, run the unchanged canonical tests, and retain the intended violation and actual result; record an unexecuted hypothesis as unverified, never as rejected. If a candidate passes while violating the contract, fix the weak assertion or genuinely ambiguous prose, update the ledger, rerun the candidate to prove it now fails for the right reason, and recheck the reference and relevant correct alternatives. Do not finalize while any known incorrect implementation passes. A merely different correct solution is not a bypass, and its internal design must not be forbidden.

- **Test environment as attack surface.** Reject solution code that changes behavior after detecting test filenames, new test-file basenames or their hex suffixes, testcase names, runner arguments, stack frames, executable names, working directories, JUnit paths, test-only environment variables, source-tree contents, or the presence of test files. Scan the solution patch for these signals and, where the public behavior permits, exercise production behavior from a fresh process, clean environment, different working directory, and multiple client instances. For demonstrated test-environment gates, reproduce the counterexample through a normal shipped consumer with its actual startup, package layout, and environment, and vary independent identity signals rather than swapping one recognizable fixture for another. Retain targeted behavioral assertions and the original candidate, and avoid multiplying redundant child processes until watchdogs become the grading signal. A supplied log is not proof that its replay passed here
- **Substrate enforcement.** When a test passes because something threw, refused, or returned the expected value, establish what produced it. A contract enforced by the storage engine, framework, runtime, type checker, schema constraint, or operating system proves nothing about the implementation. Assert the implementation's own artifact, mutate its check away to confirm the test fails, and where the repository supports more than one backend or mode, exercise the one lacking the substrate guarantee
- **Bulk and damaged state.** A per-item rule tested with one failing item cannot be told apart from a batch-level abort; use at least two independently failing items compared order-independently. Over a corrupt or damaged starting state, assert only the settled end state every correct implementation agrees on, never the operation's own counters
- **Independent oracles.** Derive expected values from the public contract and base invariants, never through the production helper being changed or a copy of the reference algorithm. Justify any model, differential, or metamorphic relation, and use concrete discriminators so two implementations sharing a defect cannot validate each other. Vary data independently of the implementation's constants and fixture layout
- **Exact structure.** Where a necessary stated contract or stable base contract requires exact public types, JSON tags, schema shapes, enum values, sentinels, wrappers, or omission rules, test them structurally through the shipped public boundary rather than by successful serialization; optional and private representations stay open. Never expose hidden test structure through filenames, helper names, fixture values, environment flags, source-path checks, or implementation-shaped assertions
- **Base-satisfied cases.** Do not add a standalone new testcase that the raw base already satisfies; fold legacy-compatible assertions into a testcase that also requires the new behavior
- **Solver patches.** When real solver patches are available, replay each relevant one against the final canonical tests in a fresh terminal checkout with the original test/wrapper bytes and manifest. Candidate edits that weaken tests, redirect execution, or forge reports are not valid passes; genuine supplemental solver tests may coexist with the required baseline. For each passing patch, check every stated contract, including paths the visible tests may not distinguish; a violating one needs a minimal reproducible counterexample and a fair assertion that rejects it. Record candidate identity, contract, input or transition, expected versus observed behavior, and the named discriminator. If none are available, say so and never claim a replay occurred. This team kit never starts paid or server runs; request missing evidence from the owner instead. Preserve the original contract and verdict of historical patches: a repair can expose a violation of an existing contract, but a new obligation never turns a correct old solution into a false positive. Label diagnostic re-evaluation separately from fresh blind solves
- **Correct solutions.** A correct independent solution is a valid success, even when shorter or structurally different from the reference; an unexpectedly small one is evidence to reconsider hardness, not permission to add implementation-shaped assertions. Check a server false-positive flag against the actual candidate, current contract, and a reproducible violation; fix genuine gaps, clarify ambiguity, and document a disputed flag with evidence. Never claim immunity from future false positives, full coverage of unbounded inputs, or first-submission approval from local checks

### Mutation Evidence
For each independent behavioral contract or tightly coupled contract group, remove, invert, hardcode, cache, or weaken only that reference behavior and confirm a specific named testcase fails for the intended reason while unrelated contracts remain observable. Mutating one or two representative lines is insufficient while other requirements remain unprobed. Interacting contracts also need combined mutants that pass each contract alone but break their composition.

- Every mutation used as evidence must compile and fail a targeted behavioral assertion. A non-compiling mutant proves nothing and is never recorded as a kill; re-aim, rebuild, and rerun. Compilation damage, unrelated regressions, and timeouts without a named assertion are not evidence
- Confirm the edit matched the intended site, the mutant sits on a branch the test actually reaches, and the mutated binary actually ran. A zero-match replacement, fixture panic, teardown failure, unrelated failed testcase, or stale output is an invalid experiment. Inspect the named assertion even if the aggregate suite is red
- A surviving single-site mutant can be masked by legitimate layered enforcement: investigate reachability and alternate guards, then use a compiling contract-group mutant if appropriate. Never delete a base invariant or force one enforcement location just to make a mutant lethal
- Restore the reference after every mutation, compare the restored tree byte-for-byte with the frozen reference patch, and rerun the complete new suite. After every solution refactor, rescan each recorded mutant's anchor text and rerun those whose site moved
- Run mutations from isolated or cleared build outputs with cache and fingerprint environment set inline. Never run verification, base probes, or falsification concurrently with a mutation harness sharing the worktree or build cache
- Record requirement, covering testcase, mutant, expected failure, actual failure, and restoration result in the ledger

---

## 6. Building the Artifacts

### Write test.sh
Invocation contract:

```bash
./test.sh --output_path results.xml base
./test.sh --output_path results.xml new
./test.sh base --output_path results.xml
./test.sh new --output_path=results.xml
./test.sh base
./test.sh new
```

Modes and arguments:
- Exactly two modes, `base` and `new`. Accept `--output_path <path>` and `--output_path=<path>` before or after the mode, and write JUnit XML to the exact requested path, creating its directory first
- When `--output_path` is omitted, write to `test-results/<mode>.xml`; both forms run the same underlying commands
- Require exactly one mode and at most one nonempty output path. Print usage to stderr and exit 2 for a missing or duplicate mode, missing or duplicate output-path value, empty `--output_path=`, or any unknown argument
- `base` runs the existing tests of the packages, modules, or components touched by the solution patch, must pass on the raw commit, and never runs only unrelated stable packages for a passing signal. Where those packages contain new tests, exclude only the new tests by name, prefix, tag, or explicit selection. If no existing tests cover a touched package, run the nearest upstream or downstream tests exercising the changed path and state why they are the closest valid regression coverage. Before final verification, compare the solution patch file list with the `base` commands and fix any mismatch. Exclude an existing test only when it is flaky, network-bound, or resource-bound, never because the solution breaks it, and justify each exclusion in one short test.sh comment
- `new` runs all newly added test files and no pre-existing tests, and must fail on the raw commit
- The verifier reads the exit code for pass/fail and the JUnit XML for per-test detail

Behavior:
- Deterministic: no timing, sleep, randomness, network calls, or race conditions; works offline with `--network none`
- No timeout or watchdog within a small factor of a testcase's nominal cost; a timeout that can decide a result is a nondeterministic assertion, never behavioral evidence. Give fixture validity windows enough headroom that a slow runner cannot expire them, and use fake clocks for boundary assertions
- No implementation code, only test assertions, using the repository's existing framework and conventions
- Do not rename or modify any pre-existing test file, test case, suite, helper, fixture, type, variable, constant, or identifier
- Name every new test case, suite, helper, fixture, type, variable, and constant by the repository's normal conventions, with no benchmark or platform word inside test code. Put each new test file in the repository's normal test folder under a specific, non-obvious basename that ends in a short random hex suffix before the normal test suffix and extension and still matches the runner's discovery pattern, for example `list_order_7c2e41_test.go`, `test_capacity_snapshot_3f9a1c.py`, or `capacity-snapshot-8d2e47.test.ts`. Generic feature-only names such as `capacity_snapshot_test.go`, `test_capacity_snapshot.py`, or `capacity-snapshot.test.ts` are forbidden, because a solver's own test file of the obvious name collides with or shadows it; no `-new` suffix either. List every added basename before exporting test.patch
- Treat patches like a real PR and do not leak the quest: no file, directory, identifier, or comment containing `challenge`, `quest`, `olympus`, `shipd`, `mars`, or `benchmark` in any case, where `mars` means a name part, not an ordinary word such as marshal; no `test.sh` comments referencing the task
- Keep the framework's real failure diagnostics and assertion output in the JUnit report; never replace upstream failures with catch-all messages or report results that did not run

Preferred template:

```bash
#!/usr/bin/env bash
set -eu
MODE=""; OUTPUT_PATH=""; USAGE="Usage: $0 {base|new} [--output_path <path>]"
usage_error() { echo "$USAGE" >&2; exit 2; }
while [ $# -gt 0 ]; do
  case "$1" in
    base|new) [ -z "$MODE" ] || usage_error; MODE="$1" ;;
    --output_path)
      [ -z "$OUTPUT_PATH" ] || usage_error
      shift
      [ $# -gt 0 ] && [ -n "$1" ] || usage_error
      OUTPUT_PATH="$1"
      ;;
    --output_path=*)
      [ -z "$OUTPUT_PATH" ] || usage_error
      OUTPUT_PATH=${1#--output_path=}
      [ -n "$OUTPUT_PATH" ] || usage_error
      ;;
    *) usage_error ;;
  esac; shift
done
[ -n "$MODE" ] || usage_error
[ -z "$OUTPUT_PATH" ] && OUTPUT_PATH="test-results/${MODE}.xml"
mkdir -p "$(dirname "$OUTPUT_PATH")"
case "$MODE" in
  base) <run the complete touched-area existing tests and write JUnit XML to "$OUTPUT_PATH"> ;;
  new)  <run all newly added test files and no pre-existing tests, writing JUnit XML to "$OUTPUT_PATH"> ;;
esac
```

Framework setup:
- `pytest`: `pytest tests/ -v --junitxml="$OUTPUT_PATH"`
- `vitest`: `vitest run tests/ --reporter=junit --outputFile="$OUTPUT_PATH"`
- `jest`: `jest-junit` is pre-installed in the base image; set `JEST_JUNIT_OUTPUT_DIR="$(dirname "$OUTPUT_PATH")"` and `JEST_JUNIT_OUTPUT_NAME="$(basename "$OUTPUT_PATH")"` before `npx jest tests/ --reporters=jest-junit`
- `go test`: `go-junit-report` is pre-installed; run `go test -v -count=1 ./pkg/... -timeout 10m 2>&1 | go-junit-report -set-exit-code > "$OUTPUT_PATH"`. The `-v` flag is required because the reporter parses verbose output
- `mocha`: `mocha-junit-reporter` is pre-installed; run `mocha tests/ --timeout 10000 --reporter mocha-junit-reporter --reporter-options mochaFile="$OUTPUT_PATH"`
- `deno`: `deno test tests/ --junit-path="$OUTPUT_PATH"`
- With no stable built-in JUnit reporter, generate valid JUnit XML in `test.sh` without runtime network access

#### Harness Integrity
JUnit is the structured record of which tests actually ran and how each ended. Implement and verify these rules while creating test.sh, never deferring report correctness to independent or server review; they are mandatory even when the optional helper is unavailable. Structural success does not prove real execution, failure causality, coverage, or resistance to incorrect passing solutions.

- **Frozen manifest.** Draft the expected-test inventory from discovery and the ledger, reconcile it with a complete native report including parameterized, nested, generated, and async cases, and freeze it before evaluating any wrong or real candidate. Never infer the list or count from a candidate's report. JUnit identity is the full enclosing suite-name path, classname, and testcase name under a fixed reporter configuration; sort by that tuple and reject duplicates. Other reporters need a documented equivalent stable identity
- **Exact membership.** Compare the canonical sorted manifest exactly with both clean and solved new-mode reports; count equality cannot reject missing, extra, renamed, duplicated, substituted, or mode-wrong IDs. Base mode with open-ended discovery requires every canonical existing ID, excludes new-test IDs, and allows extra genuine passing solver-added tests; use exact base membership only for a closed selection. Never count helpers as testcases. Canonical required IDs stay present, unique and attributable, and supplemental solver tests stay separately identified without replacing or concealing required cases. Never reject an otherwise correct candidate solely for adding legitimate tests, and investigate parameterized identity changes rather than silently dropping canonical coverage
- **Real execution.** Clean new mode requires every declared testcase to execute and fail for its own contract; skipped, synthetic, fallback-only, and stray package-level `[build failed]` cases are invalid. When public API symbols do not exist at the base commit, use compile-safe discovery so each declared testcase executes its own named discovery or behavioral assertion; one global preflight cannot stand in for the rest. Solved new mode requires every declared testcase to pass. Inspect parameterized, table-driven, generated, and nested results individually; a failing parent never excuses a passing or missing child
- **Stub first.** Write a valid failing JUnit stub to the requested path before dependency resolution, compilation, or discovery. Stub cases are failures, not skips, with node IDs from the current mode only. Replace the stub only with a produced report that exists, is nonempty, and parses; keep a valid partial-failure report even when a converter exits non-zero
- **Statuses and diagnostics.** Capture runner and reporter statuses immediately and independently, since a pipeline's last exit code alone can hide a failed test process; for Bash pipelines read PIPESTATUS before another command overwrites it, and account for converters that propagate failures while producing valid XML. Validate XML structure and individual outcomes as well as exit status: reject empty or malformed XML, unexpected skips, build or collection errors presented as behavioral failures, suite-level errors, and inconsistent totals. Preserve the first root-cause compiler, collection, exit-code, or signal diagnostic plus the log tail, publish reports atomically, force a non-zero wrapper exit when XML validation fails, and never rewrite evidence into a generic or fabricated report
- **No fail-fast.** Do not use framework fail-fast flags. Run every intended target after independent failures, making missing targets visible rather than silently short-circuiting, and keep compiler and diagnostic stderr out of machine-readable stdout
- **Trusted inputs.** Base mode runs genuine pre-existing repository tests, never an authored substitute. Resolve image-owned tools and caches through explicit absolute paths with controlled fallbacks so grading environment variables cannot redirect the harness to agent-controlled caches. Build in harness-owned absolute directories outside the repository when outputs could influence results, and explicitly build subprocess binaries tests execute when the framework does not declare them. Derive the repository root from the wrapper or loaded module, not the caller's working directory, so a neighboring solved checkout, test-only tag, edited vendor copy, or stale generated consumer cannot rescue a missing fix
- **Probes.** A fallback under a declared testcase name is diagnostic evidence, never proof of execution; perfect IDs and counts can be fabricated by TestMain or equivalent hooks, so inspect native execution evidence. Probe zero discovery, renamed or skipped tests, package build failure, reporter failure, malformed XML, suite-level errors, same-count substitution, an aborted tail, a surviving fallback stub, environment redirection, stale build outputs, and a test-aware implementation; none may pass
- **Checker.** When `f2p_check.sh` is available, always call it with the no-solution JUnit file and the explicit expected count, such as `./f2p_check.sh new_nosol.xml <expected_count>`, and inspect the reported IDs and failure reasons. A green exit code, zero discovered tests, or an all-failed stub is not evidence
- Keep `test.sh` executable and include it in `test.patch`. Run `test.sh` itself in every verification state; static linting or direct framework commands are not substitutes

#### Rust and Cargo Harness Rules
Apply only to Rust repositories.
- Keep Dockerfile and `test.sh` fingerprint environments identical for `RUSTC_BOOTSTRAP`, `RUSTFLAGS`, `RUSTDOCFLAGS`, `CARGO_ENCODED_RUSTFLAGS`, profile debug settings, incremental compilation, target directory, features, and toolchain
- Prefer a Cargo feature gate scoped to the tested crate over a global `RUSTFLAGS="--cfg ..."`, which invalidates dependency fingerprints
- When libtest JSON needs `-Z unstable-options --format json` on stable Rust, set `RUSTC_BOOTSTRAP=1` consistently in image build and runtime. Redirect libtest JSON stdout only; put filters and `--skip` after the correct `--`, avoid a doubled separator, and use `--no-fail-fast` when multiple targets must report
- Preserve nonempty parseable `cargo2junit` output after a converter failure, but validate membership, outcomes, and both process statuses separately
- Prefix every Cargo probe with its full environment in the same command rather than relying on exports from an earlier shell call, and never run Cargo verification concurrently with mutation or falsification sharing a target directory
- Use no test-only Cargo feature: test.patch holds only new test files and `test.sh`, and solution.patch never edits manifests (Grader-Safe Patches), so neither patch may declare one, and `test.sh` never mutates then restores `Cargo.toml`. A task that needs a manifest change for tests to compile is rejected at selection, as the public-API visibility rule below requires
- Confirm at selection time that integration tests can use already-public APIs without changing a parent `mod.rs`; reject a task whose test visibility needs implementation code in `test.patch`

### Write test.patch

```bash
git add test.sh tests/
git diff --cached > test.patch
```

The patch contains only new test files and the executable `test.sh`, adds new files without modifying or renaming pre-existing test files, applies cleanly to the base commit, and contains no implementation code. Patch ownership of every manifest declaration is unambiguous, and `test.sh` never mutates project manifests and restores them later. Avoid insertion contexts a solver is likely to modify; in sorted module or source lists, prefer append-only registration where conventions allow.

### Grader-Safe Patches
The public DeepSWE grader built from Shipd submissions (datacurve-ai/deep-swe) works as below, and the platform very likely grades the same way; each rule is safe either way:
- New tests are whitelisted by name: every new testcase has a stable, unique name, never built from changing data. A skipped or missing test counts as failed, and a duplicated name takes its worst result. No skip, todo, only, or focus markers in new tests
- A test that expects an error first checks that the function, option, or symbol exists, so a "not defined" error at base cannot pass it
- solution.patch shares no file with test.patch: the grader resets every file test.patch touches before applying it, so solution changes in those files are lost
- solution.patch never edits dependency manifests, lockfiles, workspace config, or test-runner config; the grader records those edits as a cheating signal. A dependency the tests need comes in through the Dockerfile, and a task whose correct fix needs a new dependency is usually a poor candidate, since a real PR would edit the manifest
- Build and verify from a fresh clone at the pinned commit, so local node_modules, .venv, or build output cannot slip into the image through COPY . .
- If the repository keeps real source under a folder named build, dist, target, node_modules, __pycache__, or .venv, tell the owner to list its full path under Protected source folders before the FP check; otherwise that code is dropped and a correct pass can read as a false positive

### Implement the Solution and Write solution.patch

```bash
git apply test.patch
```

- Satisfy every problem requirement, not merely the visible tests, with no regressions, following existing repository patterns. No minimum or maximum LOC or file count applies; keep changes necessary and idiomatic and accept correct alternatives with different file layouts
- Map every changed production line to a stated contract, necessary cross-layer integration, or established repository invariant. Remove speculative abstractions, duplicated logic, unreachable branches, accidental public API expansion, unjustified defensive code, padding, and AI-generated artifacts. Make no irrelevant changes
- Audit the reference against problem.md independently of the suite; a green suite is not evidence it is correct. Check every branch for a fixture family whose shared constant would hide it
- Audit every success, error, cancellation, timeout, retry, and early-return path for resource cleanup, state rollback, error-cause preservation, and idempotency where applicable. Introduce no unbounded queue, task, file, handle, memory, or retry growth
- Verify compatibility at every changed public boundary: API types, schemas, serialized state, migrations, feature modes, generated declarations, and old persisted data where the repository supports them
- Trace the shipped composition root and every consumer of a changed predicate: package declarations, generated descriptors, startup registration, deployment permissions, bundles, and dependency-mode compatibility the solution relies on. Default production builds must expose the feature; tests, test-only flags, vendor-only edits, or test-time regeneration never supply missing production code. Preserve existing public documentation when relocating declarations
- Add no dependency, global mutable state, background work, cache, retry, or fallback unless the contract needs it and it follows repository lifecycle conventions
- Run the repository's pinned formatter, linter, type checker, static analysis, and applicable race, sanitizer, or concurrency checks from the correct working directory over every changed implementation file and the entire new test directory; new test files are graded artifacts. Invoke them on explicit file lists with no autofix flag and no directory glob, revert any file the change did not intend to touch, and place insertions in shared export, index, or registry files in sort-correct position by hand. Choose hex-suffixed test basenames that already satisfy the repository's file-naming lint; never disable a lint rule, since neither patch may carry a lint-config edit. A different config, unavailable tool, or clean runtime suite is not a passing check, and a pre-existing unrelated failure is isolated with evidence, never waived
- Production behavior never detects tests, fixtures, runners, source paths, environment markers, or artifact filenames, and stays correct from fresh processes, clients, and working directories

```bash
git add src/ lib/ pkg/
git diff --cached > solution.patch
```

solution.patch contains only the production surfaces the behavior requires, including config, schema, migration, or generated consumer declarations when the contract needs them, and no tests, test helpers, test-runner configuration, reports, or unrelated artifacts. It applies cleanly after test.patch, adds no network-dependent runtime dependency, and contains no nonfunctional comments. Under the current contract test.patch provides test.sh; an apply error alone never justifies changing that ownership or deleting a pre-existing file.

Before freezing, check both patches the way a reviewer reads them:
- Read each solution hunk with its enclosing base code. If a finding overlooks that context, provide the exact base lines and a reproducer; fix the reference only for a valid defect, and add diff context rather than restructuring correct code for a truncated view
- Apply both patches to a fresh worktree of the pinned base in the platform's order under `git apply --whitespace=error-all`; fix whitespace and mode findings. New files show `--- /dev/null`
- Validate the deliverables from the patches alone in a clean checkout, including stored bytes, executable modes, and new files; an untracked authoring file is not evidence
- Scan both patches for platform vocabulary in contents and paths
- When one file repeatedly fails to apply while the rest succeeds, treat the second failure as base divergence and look one call frame up: a wrapper, local API, or export site publishing the same surface is a second seam, and the untouchable layer can often be disabled through its own arguments

### Dockerfile
On a repository with a successfully built setup, this step is inspection only under Preserve an Already Built Docker Setup. When no built setup exists, or Docker work is otherwise necessary, follow `docker_setup.md`.

### Verify
Run the actual wrapper in four fresh terminal states, using the pinned toolchain without fetching dependencies at test time or depending on host-global configuration:

| Checkout state | Command | Expected result |
|---|---|---|
| Unsolved, test.patch applied | `./test.sh --output_path /tmp/base_clean.xml base` | Exit 0; related existing tests pass |
| Unsolved, test.patch applied | `./test.sh --output_path /tmp/new_clean.xml new` | Nonzero; every declared new testcase fails for its intended contract reason |
| Solved, both patches applied | `./test.sh --output_path /tmp/base_solved.xml base` | Exit 0; related existing tests pass |
| Solved, both patches applied | `./test.sh --output_path /tmp/new_solved.xml new` | Exit 0; every declared new testcase passes |

- Bind each report to its mode, revision, exact command, independently captured statuses, and native log; use separate fresh output paths, retain all four, and isolate working trees and build outputs. A leftover report, correct count with substituted IDs, or failing parent hiding a missing child is invalid evidence
- Verify the explicit expected new-test count and exact membership. Zero discovery, missing targets, all-skipped reports, or an all-failed stub without real node IDs are invalid even when an exit code looks right
- Exercise both `--output_path` syntaxes before and after the mode, the default path, and usage errors exiting 2
- Run `harness_lint.sh`, the stamped four-state verifier, the false-positive checker with the explicit count, and language checks such as `no_std_check.sh` when available. Compile the repository's default supported feature set and feature variants the problem names
- Measure the unavoidable fresh compile floor of the new tests during selection; reject tasks whose runtime-only test target approaches the hard limit
- Clear or isolate build outputs before trusting false-positive probes, account for global configuration and environment variables that place caches outside the worktree, set cache paths inline on every command, and never run falsification, mutation, base probes, or wrapper tests concurrently on a shared tree or build cache
- Label evidence as `Docker verified`, `prior unchanged Docker verification reused`, or `Docker not verified`, never one as another. Terminal results describe the current artifacts; image proof describes the environment. Record any host/image mismatch
- After a fix, run the targeted check and then the complete four-state acceptance once on the final revision. Do not repeat successful expensive checks on unchanged artifacts

### Platform Check Pre-Sweeps
The owner runs the platform's quality checks; prepare for them locally so their first run is green. After any description edit the owner reruns Task Prompt Quality first, since it is cheap and the other checks go stale anyway, then Test Quality and Solution Quality, and Auto Review last.
- **Task Prompt Quality** counts distinct requirements and blocks when there are too many, and also flags redundancy, templated structure, and details an agent could find in the repository on its own; fix all of them in one edit. A failure for asking too many distinct things cannot be contested. Every sentence added to satisfy another check counts toward the limit, so prefer behavior that is repository-discoverable or covered by existing base tests. If the count fails, first remove redundancy and merge compatibility clauses; if it still fails, drop a whole feature family with its tests and code, never single sentences
- **Test Quality** reads what each test asserts, searches the description for those words, searches the repository's source, tests and docs and cites file:line, then labels each test Prompt-stated, Repo-discoverable, or Not fair. One Not fair test fails the whole task. A test is Not fair when another implementation could satisfy the description and still fail it, such as a lazy evaluation, a short-circuit, or a different grouping shape, even when the reference passes. It tags brittle_message_matching on assertions of human-readable error text. Before handoff, write the description sentence or base file:line behind every test; when a feature reaches a new place, such as a new path form inside an existing filter, the description defines how it behaves there; assert no resource limits, laziness, performance, or evaluation order the description does not ask for, and beware fixtures such as a zero limit that a correct implementation may short-circuit; never add a test that separates two readings the description leaves open; test every operator or API a requirement names and every existing option new syntax must coexist with; prefer multi-row fixtures, collision cases such as an item property against a same-named global, and expected values derived by a small helper
- **Solution Quality** scores Solution Comprehensiveness and Code Quality out of 3 each, and either falling short fails even when every test passes. It quotes each promise, traces the code paths including shared helpers used from several places, builds inputs that combine two promised features, and checks the patch against the repository's lint configuration. Check every promise alone and in pairs, every caller of reused code, ambiguous new syntax resolved by one stated rule with an explicit form for the other meaning, and the repository's own lint and check scripts on the patched tree, and give every pair found a test
- **Auto Review** runs separate reviewers for prompt, tests, solution, and agent runs and scores each band by its worst verified finding: none 3, Medium 2, High 1. One High finding drops a band to 1, and any band below 3 usually means Revision Requested. Findings use the platform guide's own IDs P1 to P7, T1 to T8, and S1 to S4, which are not this file's checklist IDs, each with the promise cited, a failing case, a wrong implementation the tests miss, the load-bearing code line, and the expected fix. It is non-deterministic and digs somewhere new each run, so sweep every file the patch touches before handoff: the shortest wrong implementation per requirement; values where the language's built-in behavior differs from the repository's rules, such as truthiness of 0, the empty string, empty arrays, and null versus missing; present-but-null versus missing at every path position including the last; empty collections, null elements, and non-collection values where a collection is expected; every repository mode and option that affects the touched code, run rather than read; both copies of any near-duplicated new branch; every documented public surface, such as sync and async, render versus parse-and-render, file, streaming, and CLI; inputs the replaced parser or lookup accepted, each giving the old result, with a new parser either consuming the whole input or falling back; every branch with its own parsing, such as if, elsif, unless, and the elsif inside unless; and both outcomes of every boolean or found/not-found API under the new syntax, with the false case folded into a test that still fails at base. It also grades agent-run coverage and reports missing evidence without 4 or more runs on each codename, which is why it runs last
- **Contract table.** When checks keep finding new edge cases in one area, the description usually holds two conflicting promises, such as a universal new rule and old forms still working. Stop fixing findings one by one: build one table of each call form, old and new, against each relevant option, with the expected result and whether it comes from base or the new contract; scope every universal sentence to the forms it really covers; and make code, tests, and description match the table
- Prove every lint or gate claim with the command's output on a fresh base with the patch applied, and confirm the patch on the platform is byte-identical to the one checked

---

## 7. Delivery

Deliver these files:

| File | Contents |
|---|---|
| `problem.md` | Prefer 300–500 words, at most 500 including the title, at most 12 atomic requirements; natural paragraphs without headers, bullets, or code blocks |
| `test.sh` | Base/new modes, both output-path syntaxes in either order, default JUnit paths, deterministic execution, no nonfunctional comments |
| `test.patch` | New test files and executable test.sh; applies cleanly to the base commit |
| `solution.patch` | Implementation only, no LOC bounds or padding, no nonfunctional comments |
| `Dockerfile` | Builds successfully; runtime tests work offline; `CMD ["/bin/bash"]` |

Upload metadata:
- **Title**: a concise title for the repository-discovered task
- **Description**: a 2–3 sentence summary of what the challenge requires
- **Category**: one of `bug fix`, `feature request`, `refactor`, `performance`, `concurrency`, `config/schema change`
- **Repo**: full repo URL and base commit hash
- **Track**: `Olympus`
- **Difficulty**: X/10
- **Local calibration**: genuine solves over valid attempts from the four scheduled attempts, with invalid count, artifact revision, and met/missed/incomplete/stale status; unmeasured until it runs

Hand off to the owner, who performs every platform operation, the local artifacts, original review approval, current hashes, test evidence, calibration results and limitations; never claim server acceptance from local results. For a current Docker verification, report the clean-image and solved-image results; for an allowed reuse, report the four terminal states and the prior Docker artifact digest. Never label terminal-only evidence as a current image run.

### Reading Solver Evidence
Label an unmeasured rate as an estimate. With solver-run evidence, report the model/cohort, artifact revision, valid-run denominator, score distribution, and failing contract clusters, and separate infrastructure-invalid runs and unfair assertions from semantic misses. Reference success is not independent solvability evidence; never project an old rate onto a changed contract or call a hypothetical post-fix pass an observed result. Read a cohort by cluster and compute what fraction of the suite actually separated the runs:
- When most failures concentrate on one contract, investigate ambiguity, unfair assertions, harness errors and genuine difficulty before changing anything. Past zero-pass cohorts were caused by an unstated ordering rule, a qualifier in the wrong clause, a dropped word, a compressed sentence binding to the wrong subject, and an option key the prose never named. Fix demonstrated ambiguity; keep fair assertions for behavior already stated
- When most of the suite discriminates nothing and one omission carries the rate, clarify the missing behavior and reassess difficulty within scope. If the coherent task is too easy, select another problem rather than adding an unrelated dimension
- Solver/reference code-size differences alone establish neither a checklist nor hardness; inspect whether the prose prescribes implementation steps and whether correct solutions require genuine repository reasoning. Remove unnecessary recipes while keeping tested contracts, and never add scope to lower a pass rate
- A hint may name observable state, outcomes, partitions, precedence, and boundaries, never a helper, file, algorithm, control flow, or reference design
- A near-complete zero-pass cohort can expose ambiguous prose or one narrow omitted contract; it does not prove the central architecture was unsolved
- Analyze one model cohort at a time, since mixed-model aggregates hide model-specific ambiguity, and separate solve-time friction and toolchain noise from recurring semantic failures
- Read Nova, Orion, and Vega separately, each with its pass rate and the sequence lengths of its runs, passing runs apart, and adjust with the tuning table in The Target Profile
- Check the owner target per codename: valid unhinted denominator of at least 4, Orion above 0% and at most 25% (1 of 4), Vega and Nova at 0%, and Nova's average sequence length above 400K computed per run as `sequence_largest` plus the sum of `sequence_removed`. Use the run JSON the owner exports with the official CLI (`olympus checks view <id> --json`, `olympus runs view <id> --json`) rather than numbers copied from the screen; this kit never runs that CLI
- Read the banner above the owner's runs; it names the next step (quick check, full batch, too easy, looks broken, ready)
- When the owner changed only test.patch or solution.patch, Re-eval re-grades the archived agent solutions against the new patches at about 30% of the cost of fresh runs. It does not apply after a title, description, or environment change, which need fresh rollouts, and starting a fresh run instead forfeits the offer, so the owner decides first. Re-eval re-grades every archived run at once, so a single shared blocker can flip a model from 0% to 100% with nothing in between: read the result per run before trusting the new rate
- Every pass must be genuine and every failure fair: a failure the evaluator marks as not mentioned in the description needs the sentence added or the test dropped, and a thin or partial pass means the tests have a gap

| Track | Difficulty | Pass rate | Benchmark quality |
|---|---|---|---|
| Local target | Above 9/10 estimate | 0/4 genuine solves from 4 valid attempts | Diagnose failures for fairness and environment defects |
| Platform evidence | Measured separately | At least 4 completed unhinted runs on each of Nova, Orion and Vega; Orion above 0% and at most 25% (1 of 4), Vega and Nova at 0%, as the owner target within the panel bar; Nova averaging above 400K | Current task and agent line-up only; sequence lengths per codename from the server, never estimated locally |

---

## 8. Olympus Acceptance Checklist

Record PASS, FAIL, or NOT APPLICABLE with reproducible evidence for every item. NOT APPLICABLE requires repository evidence or this profile's explicit authorization boundary, such as owner-only remote operations; that boundary cannot waive a required local gate. Cost, time, or inconvenience is not a justification. Any failure, missing evidence, or unresolved finding blocks completion, and an aggregate green run cannot override an atomic failed gate. Each item points to the section that owns its rule.

### Repository Gate
- R1: The repository is active, public, production-level, has at least one commit in the last 12 months, has 500+ stars, is written in TypeScript, JavaScript, Python, Go, Rust, C++, or Java, and has a license on the guide's permissive list (MIT, BSD, Apache, Boost, CC-BY and listed variants)
- R2: No open, merged, closed, or abandoned PR already implements the same idea
- R3: Maintainers have not declined the feature or behavior in issues, PRs, or Discussions, and the capability was not shipped earlier and then removed on purpose
- R4: The task fits the repository's philosophy and is not a generic feature copyable into unrelated projects
- R5: Open and draft PRs were searched by specific mechanism and target file paths before implementation, and none implements the same machinery

### Problem Description Gate
- P1: The task aligns with the repository's philosophy, originated from repository exploration, and overlaps no existing or accepted task by name, function, or mechanism
- P2: The task is not already fixed in an open, merged, closed, or abandoned PR
- P3: The description is self-contained and solvable from only the repository and problem text
- P4: The description is clear, concise, unambiguous, and leaves no behavioral guessing
- P5: The requested behavior is objectively verifiable by tests
- P6: The description does not prescribe or leak the solution, internal layout, helper names, or implementation path unless part of the public contract
- P7: The task is not a duplicate or near-duplicate of an existing submission; similarity results were read
- P8: A natural request preferring 300–500 words and never more than 500 including the title (Writing problem.md)
- P8a: Every assertion maps to necessary problem behavior or an identified stable base contract; exact strings follow the exact-string rule (Contract Synchrony)
- P8b: Qualifiers distribute correctly, competing refusals name a winner, necessary error translations are stated, and no clause binds to the wrong subject (Contract Synchrony)
- P8c: An independent clause-by-clause decomposition reconciles to at most 12 atomic requirements; 13 or more, a bundled row, or an unresolved count is FAIL. Ultra Max and cleanup evidence and a Pangram AI score below 0.5 exist for the exact final text; missing, stale, or failing evidence blocks approval and upload. Neither gate is advisory
- P8d: The description passes the Plain-English Test and contains none of the forms Description Quality rejects (Writing problem.md)
- P8e: The selection record passes all three Target Profile gates line by line: hard for most runs, solvable by Orion, and long horizon, with the Nova long-horizon estimate recorded (The Target Profile)
- P9: The Platform Check Pre-Sweeps are done on the final bytes: requirement count and redundancy, a description sentence or base file:line behind every test, every promise alone and in pairs, the Auto Review sweep, and the contract table where needed (Platform Check Pre-Sweeps)

### Test Gate
- T1: New tests fail 100% at the base commit and pass 100% after the solution patch
- T2: Tests are deterministic with no timing, randomness, ordering, race, or machine-specific dependence
- T3: Inaccurate, narrow, or partial implementations do not pass
- T4: Tests cover the requested behavior and its edge cases
- T5: Tests require no unspecified, hidden, or undiscoverable behavior
- T6: Tests require no network access and pass under `--network none`
- T7: Tests do not over-pin output, error text, formatting, or wording unless the contract or base behavior makes it obvious
- T8: Failure results keep real testcase identity, assertion output, and upstream diagnostics (Harness Integrity)
- T9: Pre-existing tests are unchanged; new test files sit in the normal test folder under specific, non-obvious, hex-suffixed basenames, and identifiers inside new test code follow repository conventions (Write test.sh)
- T10: Patches leak no `challenge`, `quest`, `olympus`, `shipd`, `mars`, or `benchmark` names or text in any case (Write test.sh)
- T11: `base` runs existing regression tests of the touched packages, excluding only new tests
- T12: The invocation contract holds for both syntaxes, either order, default paths, and usage errors
- T13: Every atomic requirement has a positive test and, where a near-miss exists, an adversarial test (Task Ledger)
- T14: Every assertion maps back to stated behavior or a documented repository invariant (Contract Synchrony)
- T15: Fixtures vary across every form, lifecycle path, boundary, ordering rule, persistence source, and failure mode the stated obligations reach (Coverage)
- T16: Necessary exact public types, tags, schemas, enums, sentinels, wrappers, or omission rules are checked structurally; otherwise equivalent representations are allowed (False Positives)
- T17: Contract-level mutations fail the intended tests and no known incomplete, hardcoded, cached-state, or test-aware patch passes (Mutation Evidence)
- T18: Every stated behavior, meaningful branch, supported form, boundary, lifecycle path, retry, persistence source, and independent failure has a named positive test and a near-miss where meaningful (Coverage)
- T19: JUnit is stub-first, fallback cases are mode-correct failures, valid partial reports survive, and counts match the declared set (Harness Integrity)
- T20: Structured stdout is uncorrupted, all targets run after independent failures, and missing targets cannot pass (Harness Integrity)
- T21: Base mode runs genuine existing tests; subprocess binaries are built explicitly; tools, caches, and build directories cannot be redirected (Harness Integrity)
- T22: New test filenames and identifiers reveal no implementation path, source location, fixture shortcut, environment flag, or collision surface
- T23: The ledger maps every atomic contract to positive and adversarial coverage and every assertion back to a contract (Task Ledger)
- T24: Every testcase is independently fair: correct alternatives pass and failures identify their own violated contract (Fairness)
- T25: The false-positive checker runs with the explicit count, reports the exact node-ID set, and rejects every harness cheat (Harness Integrity)
- T26: The coverage inventory accounts for every entry point, form, partition, boundary, transition, state source, retry, failure, ordering rule, concurrency guarantee, cleanup path, exemption, compatibility path, and meaningful branch of the stated obligations (Coverage)
- T27: Every ledger row names exact testcase IDs, positive and adversarial evidence, a compiling mutation, and its expected failure; the final report contains that exact set and count (Task Ledger)
- T28: Native line and branch coverage was inspected with zero unexplained behavioral gaps (Coverage)
- T29: No arbitrary test-count cap; finite partitions are enumerated and unbounded domains use documented deterministic techniques (Coverage)
- T30: Stateful, concurrent, and cross-layer contracts have explicit transition and interaction matrices (Coverage)
- T31: A problem-only reconstruction finds no requirement depending on the reference, hidden fixtures, or an unstated interpretation (False Positives)
- T32: The cheat inventory is complete and each item has a named discriminator and result (False Positives)
- T33: The solution patch keys no behavior to test signals (False Positives)
- T34: New mode discovers every testcase from every new test file and no pre-existing test, with exact membership in clean and solved states (Harness Integrity)
- T35: Every dimension the stated obligations reach has at least two samples capable of disagreeing (Coverage)
- T36: No unfair assertion shape remains (Fairness)
- T37: Every restrictive assertion has a named materially different correct implementation that passes, and no assertion survives a mutation breaking no stated contract (Fairness)
- T38: No timeout, watchdog, fixture expiry, or scheduling margin can decide a result; observers register before the transitions they observe (Write test.sh)
- T39: No testcase passes on substrate enforcement alone; bulk contracts use two independently failing items; damaged-state assertions pin the settled end state (False Positives)
- T40: No pre-existing repository test asserts behavior the correct change must alter, and no test requires an ordering, timing, or startup sequence the description does not state (The Target Profile)
- T41: Every new testcase has a stable unique name, with no skip, todo, only, or focus marker and no name built from changing data (Grader-Safe Patches)
- T42: Every test that expects an error first checks that the function, option, or symbol exists (Grader-Safe Patches)
- T43: In `base`, every excluded existing test is flaky, network-bound, or resource-bound and justified in one test.sh comment (Write test.sh)

### Solution Gate
- S1: The solution satisfies every stated requirement, not just the visible tests
- S2: No regressions; existing repository patterns followed
- S3: No irrelevant changes
- S4: No AI slop: no weird comments, padding, unexplained defensive code, or inconsistent style
- S5: Every changed production line is necessary, and every meaningful changed branch has behavioral evidence
- S6: Formatting, linting, type checking, static analysis, and applicable race or sanitizer checks pass on all touched components
- S7: Success, error, retry, cancellation, timeout, rollback, cleanup, and idempotency paths preserve invariants
- S8: Public API, schema, serialization, persisted-state, generated-surface, and compatibility obligations hold
- S9: No test detection or behavior keyed to test names, paths, environments, stack frames, or JUnit artifacts
- S10: New dependencies, globals, caches, background tasks, retries, and fallbacks are necessary, minimal, and lifecycle-safe
- S11: The solution was reviewed against problem.md independently of the tests
- S12: No LOC minimum or maximum decides correctness; the author's above-9/10 estimate is backed by the selection record's difficulty evidence and necessary-file list, without padding or hidden requirements. Calibration is not required for this pre-review item
- S13: Quality tools ran over changed implementation files and the entire new test directory on explicit file lists, with no autofix or directory glob and no unintended reformatting
- S14: The reference was audited against problem.md independently of the suite, and no changed branch is hidden by a shared fixture constant
- S15: Hunks were reviewed with enough base context, both patches apply under `git apply --whitespace=error-all` in the platform's order, deliverables were validated from the patches alone, and no platform vocabulary appears
- S16: solution.patch shares no file with test.patch (Grader-Safe Patches)
- S17: solution.patch edits no dependency manifest, lockfile, workspace config, or test-runner config (Grader-Safe Patches)

### Dockerfile Gate
- D1–D16 are in `docker_setup.md`. For a preserved setup, inspect the recorded evidence against them without rebuilding; an unmet item is an unresolved limitation under Preserve an Already Built Docker Setup

### Local Verification Gate
- V1: `git apply test.patch` applies cleanly to the pinned base commit
- V2: Unsolved, `./test.sh --output_path /tmp/base.xml base` passes and exercises existing tests related to solution-touched paths
- V3: Unsolved, `./test.sh --output_path /tmp/new.xml new` fails
- V4: Solved, both modes pass
- V5: Initial or invalidated environment proof includes the offline Docker states; afterwards every iteration and review uses the four terminal states with matching prior image evidence
- V6: A final PR, issue, and discussion search confirms no existing solution
- V7: The solution patch file list was compared with the `base` commands, and every touched package with existing tests is represented
- V8: The actual wrapper ran in all four states with exact frozen new-mode membership and correct base membership
- V9: False-positive and mutation probes used isolated or cleared build outputs with cache and fingerprint environment inline
- V10: Initial or changed-environment Docker evidence proves the clean and solved states as the grading user, UID 1000 when applicable, offline with valid XML; review checks it without repeating containers
- V11: Default supported features compile, and conditional modes such as Rust `no_std` are checked when applicable
- V12: A built Docker setup was preserved without edits, rebuilds, or container runs, with matching evidence reused and tests run in the terminal
- V13: Owner-supplied remote image status, if any, is reported separately from local evidence. The team does not trigger or poll remote builds or rerun platform checks; missing owner evidence is unknown, never a claimed server PASS
- V14: Every recorded mutation compiled, reached its branch, failed its named assertion, and was restored byte-for-byte, with no concurrent verification on a shared tree or cache
- V15: Every incoming finding was matched to the current digest and reproduced before any contract changed; confirmed defects were repaired with prose, assertions, and ledger together
- V16: The image inputs and local verification come from a fresh clone at the pinned commit, with no local dependency or build output copied in (Grader-Safe Patches)
- V17: Any real source kept under a build, dist, target, node_modules, __pycache__, or .venv folder is reported to the owner for Protected source folders (Grader-Safe Patches)

---

## 9. Superseded Rules

History and evidence only; nothing in this section is active policy. Each block is the verbatim text that the 2026-10-23 update to the live Submission criteria panel replaced, kept so no data is lost. The run evidence it cites stays valid as observations; only the criteria and rules it states are retired.

### Opening summary of the solver bar
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
Nova, Orion, and Vega are the platform's code names for its three solver agents. Nova is the weaker solver: it must fail every run, and its runs must average more than 256K tokens of sequence length. Orion and Vega are the stronger solvers: one of them must solve more than 0% and at most 25% of at least 4 runs, and the passing runs of that qualifying codename must also average more than 256K tokens. Either codename may qualify. In the owner's server evidence only Vega has run that long, so the task must make whichever stronger solver succeeds do so on a long run, which so far means a Vega run. The Target Profile describes the three agents, the evidence behind these descriptions, and the exact criteria.
```

### Local Calibration purpose sentence
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
It checks only that the task is hard enough for Nova, the weaker platform solver defined in The Target Profile; it does not measure Orion or Vega, whose rates and sequence lengths come only from server runs.
```

### Owner-only platform acceptance context (bar of 2026-10-11 and 2026-10-17)
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
The owner-supplied screenshot and current docs inspected during maintenance on 2026-10-11, and the owner-supplied criteria text of 2026-10-17, describe at least 8 unhinted Nova runs with 0% solved and average sequence length above 256K, at least 4 Orion or 4 Vega runs with a solve rate above 0% and at most 25%, and, added on 2026-10-17, that the passing runs on that qualifying codename must average more than 256K tokens of sequence length. Fairness, solvability, cheating, environment, passing-run FP review, and current review evidence are separate gates. This is handoff context only: team agents must not fetch or run platform work. The post-rollout FP check reviews passing solutions and is distinct from the prohibited Verifier Audit/VLC. Local 0/4 does not prove these server criteria and measures no sequence length. Use owner-supplied current evidence, not old acceptance or stale cohorts, and read sequence lengths per codename as The Target Profile describes.
```

### Breadth sentence in The Kind of Problem to Select
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
That same breadth is what carries a stronger solver's passing runs past 256K tokens, as Gate: long for the qualifying codename in The Target Profile requires.
```

### Target Profile introduction, criteria table and aim (earlier bar)
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
The platform grades each task with three solver agents known by code names, and it measures every run's sequence length: the largest request's prompt plus model output, plus any context the harness compacted away. Four criteria must hold at once, each counted per codename and never combined across codenames:

| Criterion | Requirement |
|---|---|
| Nova rollouts | Nova fails all of at least 8 runs |
| Long horizon (Nova) | Those Nova runs average more than 256K tokens of sequence length |
| Orion / Vega rollouts | At least 4 runs on Orion or 4 runs on Vega, solved more than 0% and at most 25% of the time |
| Long horizon (Orion / Vega) | The passing runs on that qualifying codename average more than 256K tokens of sequence length |

The last row is the binding one. None of the agents can be run locally, so design for their harnesses as observed. Either Orion or Vega may be the qualifying codename; what matters is that the codename that solves does so on runs averaging above 256K. Aim for Nova 0%, and for Orion and Vega each at 0% or inside the band, with one solve in four to eight runs on the codename that runs long. In the evidence so far only Vega has run that long, so a short Orion solve carries nothing and a short Vega solve is a long-horizon miss. Do not design a codename to fail; design the task so that a correct solve needs the long run. If Orion's harness changes and it runs long, the same gates apply to it. The profiles below come from 178 owner-supplied server runs across nine tasks in Python, Java, Go, and JavaScript repositories; they guide judgment and guarantee nothing.
```

### Orion profile sentence about the 256K solver criterion
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
Under this harness it has not come near 256K, so an Orion solve has not yet satisfied the long-horizon criterion; keep it inside the 25% band and read its solves as evidence that the task is close, not as the qualifying result unless the platform reports them above 256K.
```

### Gate heading: hard for Nova
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
**Gate: hard for Nova.** Every line must hold before implementation:
```

### Gate heading: solvable for Orion or Vega
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
**Gate: solvable for Orion or Vega.** Every line must also hold:
```

### Gate heading: long for the qualifying codename
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
**Gate: long for the qualifying codename.** The codename that solves must do so on runs averaging above 256K. Only Vega has run that long, so the lines below are calibrated on Vega's runs; apply them to whichever codename the platform reports as long. Every line must hold,
```

### Tuning lead sentence
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
Tune with solver results. Local calibration shows only whether the task is hard enough for Nova; Orion and Vega rates, and every sequence length, come only from owner-supplied server runs.
```

### Tuning table (earlier bar)
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
| Result | Meaning | Adjustment |
|---|---|---|
| Nova solves any run, or a local calibration attempt succeeds | The task is a checklist or a self-contained module | Reselect, or widen it to more existing paths; never add rules |
| Nova averages 256K or less | The work is too narrow | Widen it genuinely; never pad |
| Orion or Vega solves, but that codename's passing runs average 256K or less | The necessary reading set or the test loop is too small for the behavior | Reselect toward one outcome across more existing modules; never pad, slow, or repeat work |
| A stronger solver runs above 256K but fails every run while passing nearly every test | One obligation sits a step too far from the core path | Remove the farthest obligation or add a plain pointer to it; keep the breadth |
| A stronger solver ran few or no tests and stayed short | The solver image could not run the repository's tests | Report it to the owner as an environment finding; Docker work stays governed by Preserve an Already Built Docker Setup, and the task itself does not change |
| Stronger runs each fail many tests | Too many independent obligations | Cut scope |
| Stronger runs fail the same single test nearly every time | A hinge is too hidden | Add a plain pointer to the preserved behavior, or relax the assertion |
| One stronger solver solves short while the other fails long | Usually the near-solve case above; read the long failures first | Do not add obligations; fix the far obligation or the pointer so the long solver lands |
| Orion or Vega solves more than 25% | Too easy, or the preserved behavior is visible inside the edited lines | Turn written rules into outcomes, remove signposting, and check that the preserved behavior lives in a caller; reselect if still easy |
| A run is judged an undocumented requirement or unfair | A hinge exists only in a fixture or is unstated | Make it real and pointed to, or remove it |
| Runs are rejected for editing a graded test | An existing test contradicts the change | Reselect |
| The closest attempt fails only an unstated ordering or timing constraint | The test is stricter than the description | Remove the constraint |
```

### Hardness Gate long-horizon row
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
| Long horizon | A correct run by the qualifying stronger solver genuinely needs to read on the order of 50 files across five or more modules and to iterate a test loop, per Gate: long for the qualifying codename |
```

### Test-environment attack surface marker wording
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
the `benchmark__` marker, testcase names,
```

### New test-file naming rule (benchmark__ marker)
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- Name every new test case, suite, helper, fixture, type, variable, and constant by the repository's normal conventions, with no benchmark prefix or suffix inside test code. Add the marker only to new test-file basenames: each begins with `benchmark__`, followed by a specific scope and the repository's normal test suffix and extension, with no `-new` suffix. Generic feature-only names such as `capacity_snapshot_test.go`, `test_capacity_snapshot.py`, or `capacity-snapshot.test.ts` are forbidden. List every added basename before exporting test.patch
```

### Quest-leak word list
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- Treat patches like a real PR and do not leak the quest: no directories or files named `challenge`, `quest`, or `olympus`, no `test.sh` comments referencing the challenge, and no `Shipd` or `Olympus` text anywhere in patches
```

### Rust Cargo feature ownership rule
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- A challenge-only Cargo feature declaration belongs to exactly one patch; the other patch and `test.sh` detect it read-only and never mutate then restore `Cargo.toml`
```

### Reading Solver Evidence platform row
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
| Platform evidence | Measured separately | Nova 0% over at least 8, averaging above 256K; Orion or Vega above 0% and at most 25% over at least 4 of one model, with that model's passing runs averaging above 256K |
```

### Checklist R1
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- R1: The repository is active, public, production-level, has at least one commit in the last 12 months, has 500+ stars, uses an allowed language, and has a permissive license
```

### Checklist R3
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- R3: Maintainers have not declined the feature or behavior in issues, PRs, or Discussions
```

### Checklist P8e
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- P8e: The selection record passes all three Target Profile gates line by line: hard for Nova, solvable for Orion or Vega, and long for the qualifying codename, with the long-horizon estimate recorded (The Target Profile)
```

### Checklist T9
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- T9: Pre-existing tests are unchanged; only new test-file basenames carry the `benchmark__` marker, and identifiers inside new test code follow repository conventions (Write test.sh)
```

### Checklist T10
Source: `CLAUDE.md`, replaced 2026-10-23.

```text
- T10: Patches leak no `challenge`, `quest`, `olympus`, `Shipd`, or `Olympus` names or text
```

### self_review: marker detection line
Source: `self_review.md`, replaced 2026-10-23.

```text
- Attempt to detect the `benchmark__` marker, testcase names,
```

### self_review: Target Profile gates bullet
Source: `self_review.md`, replaced 2026-10-23.

```text
- The selection record passes all three Target Profile gates in CLAUDE.md line by line. Hard for Nova: existing code rather than a new self-contained module, at least three interacting paths or states, an outcome-style request, and a preserved behavior that lives in a caller of the changed code and is pointed to by outcome. Solvable for Orion or Vega: a finishable scope, one or two hinges in shipped code the change touches with a plain pointer in the description, a fix that can extend existing primitives, no contradicting pre-existing test or unstated timing, and every wired path tested. Long for the qualifying codename: a recorded estimate of the necessary reading set, its module count and sizes, the existing tests for those areas and their terminal runtime, and the breadth of a correct patch, honestly within the observed ranges for runs above 256K, with nothing padded to reach them and no local Docker build or run performed to establish it. File count is evidence, not the gate. A missing, padded, or failing line is a finding
```

### self_review: test-file naming line
Source: `self_review.md`, replaced 2026-10-23.

```text
The marker appears only in new test-file basenames, each beginning with `benchmark__` and a specific scope, with no generic feature-only name and no `-new` suffix
```

### self_review: quest-name line
Source: `self_review.md`, replaced 2026-10-23.

```text
- No quest or platform names in test file names, functions, or constants; test.patch holds only test files and test.sh
```

### self_review: solver-evidence reading line
Source: `self_review.md`, replaced 2026-10-23.

```text
Read Nova, the weaker platform solver, and Orion and Vega, the stronger ones, separately against the Target Profile in CLAUDE.md, reporting each codename's pass rate and the sequence lengths of its passing runs
```

### prompt.md: Target Profile summary
Source: `prompt.md`, replaced 2026-10-23.

```text
pass all three Target Profile gates in CLAUDE.md: hard for Nova, the platform's weaker solver, which must fail every run while averaging more than 256K tokens; solvable for Orion or Vega, one of which should succeed in about one run of four to eight; and long for the qualifying codename, whose passing runs must average more than 256K tokens of sequence length, which so far only Vega has reached, and only on one outcome spanning five or more existing modules with a test loop the solver could run.
```

### Calibration skill: purpose sentence
Source: `olympus-blind-calibration/SKILL.md`, replaced 2026-10-23.

```text
Its purpose is to check that the task is hard enough for Nova, the platform's weaker solver, which must fail every run: all four attempts must fail. It does not measure Orion or Vega, the stronger solvers, nor any run's sequence length; those come only from server runs.
```

### Minor wording replaced in place
Source: `CLAUDE.md` and `olympus-blind-calibration/SKILL.md`, replaced 2026-10-23.

```text
**Nova, the weaker solver.**
| Task shape | Nova | Orion | Vega | Verdict against the criteria |
inside a scope a stronger solver can finish.
is what lengthens Nova's runs past 256K and makes it miss obligations.
- Expect the qualifying solver to need about 90 steps or more at Vega's observed growth.
not proof of the platform's Nova or Orion/Vega outcomes
```

### Follow-up wording replaced in place
Source: as listed, replaced 2026-10-23 after an independent consistency read.

```text
[CLAUDE.md] | `olympus-blind-calibration/SKILL.md` | The one-time four-agent local check that the task is hard enough for Nova |
[CLAUDE.md] Where a lint rule genuinely conflicts with the required marker basename, disable only that rule for test files and record why.
[self_review.md] only a rule that genuinely conflicts with the marker basename is disabled, with the reason recorded
[self_review.md] single-patch feature ownership
[CLAUDE.md] Findings use the IDs P1 to P7, T1 to T8, and S1 to S4,
[CLAUDE.md] - D1–D13 are in `docker_setup.md`.
[self_review.md] against D1–D13 in docker_setup.md
[CLAUDE.md] intermediate 2026-10-23 Rust rule letting test.patch own a test-only Cargo feature, withdrawn because test.patch holds only test files and test.sh
```

### Replaced for the Orion-only owner target
Source: as listed, replaced 2026-10-24 when the owner required Orion 1 of 4, Vega 0 of 4, Nova 0 of 4.

```text
[CLAUDE.md] Any of the three may be the solver. With 4 runs per model that means exactly 1 of 4 on one codename and 0 of 4 on the other two.
[CLAUDE.md] The binding combination is two codenames at exactly 0% while the third lands about one solve in four. Any codename may be the solver and no task design can force which, so do not design a codename to fail or to pass: design the task so a correct solve needs the whole outcome, then let small batches show which model lands it, and do not fight the data when a different model turns out to be the solver. With 4 runs per model the solver must pass exactly once; only more runs allow a second pass within 25%. Two solving codenames means the task is too easy; none means look for an unfair or ambiguous point before adding runs.
[CLAUDE.md] Its purpose under the current bar is to keep two codenames at 0% and Nova's runs long; Nova is the usual zero and its weaknesses are the main lever, but a task whose single solver turns out to be Nova is acceptable:
[CLAUDE.md] **Gate: solvable by one codename.** Every line must also hold, so that exactly one codename lands about one run in four:
[CLAUDE.md] - Each independently wired caller or consumer of the changed behavior has its own test; a missed path costs the coverage verdict, as Coverage requires.
[CLAUDE.md] | Exactly one codename solves, at most 25%, the other two at 0% | On target | Stop tuning; run the full batch and read every pass and failure |
[CLAUDE.md] | Two or three codenames solve, or a local calibration attempt succeeds |
[CLAUDE.md] | The solving codename is above 25% | Not hard enough, or a partial solution slips through the tests |
[CLAUDE.md] | No codename solves | Unfair, ambiguous, or one obligation too far |
[CLAUDE.md] Adjust one dial at a time and rerun the small batch. Once exactly one codename solves, stop tuning and run the full batch.
[CLAUDE.md] - Check the current bar per codename: valid unhinted denominator of at least 4, exactly one codename above 0% and at most 25%, the other two at 0%,
[CLAUDE.md] exactly one codename above 0% and at most 25%, the other two at 0%; Nova averaging above 400K |
[CLAUDE.md] hard for most runs, solvable by one codename, and long horizon,
[self_review.md] against the current bar: at least 4 runs per codename, exactly one codename above 0% and at most 25% with the other two at 0%, and Nova averaging above 400K.
[self_review.md] Solvable by one codename: a finishable scope,
[self_review.md] whether exactly one codename solves at most 25% while the other two stay at 0%,
[prompt.md] exactly one of them solves more than 0% and at most 25%, which with 4 runs means exactly 1 of 4, while the other two stay at 0%;
[prompt.md] Any codename may be the solver. The live
[olympus-blind-calibration/SKILL.md] under the current bar two of the platform's three codenames must stay at 0% while exactly one lands above 0% and at most 25%,
```
