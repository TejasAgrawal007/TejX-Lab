---
name: olympus-blind-calibration
description: Measure the local pass rate of a frozen Olympus task with four independent blind gpt-5.6-sol medium solves. Run once during initial creation after local validation and independent review, or on explicit request. The team kit is local-only; never launch platform checks, server agents or routine repair cohorts.
---

# Olympus Blind Calibration

Estimate whether a frozen Olympus problem is too easy, plausibly calibrated, or probably too hard. Its purpose is a too-easy screen: under the current bar two of the platform's three codenames must stay at 0% while exactly one lands above 0% and at most 25%, so a local model that solves the frozen task predicts more than one solving codename. All four attempts must fail. It measures no platform codename's rate and no run's sequence length; those come only from server runs. Preserve blindness, evaluate independently, and report evidence. This skill is diagnostic: do not change the active problem.

## Preconditions

Run once as part of initial task creation after local validation and fresh independent review, when the final description, tests, reference behavior and scope are frozen. The creation workflow authorizes this local four-attempt gate; no separate server-run permission is implied. Also run when the user explicitly requests local calibration. Do not trigger from instruction maintenance, a status question, read-only inspection, review alone, repairs of an already-created task, or routine server feedback. Confirm the repository URL/checkout, pinned commit, description, test.patch and executable harness before launching any attempt. Record the frozen hashes and attempt IDs in existing task evidence so a resumed chat cannot start a duplicate cohort.

Do not run or read Olympus platform checks, rollouts, artifacts, or metadata. Do not sync, submit, edit the casebook or memory, or modify the active problem. Work in a disposable random directory outside the submission tree. If required inputs are missing, ask only for those inputs. Respect explicit filesystem/isolation constraints; if a clean isolated evaluator cannot be arranged, report the blocker. Use terminal tests and reuse valid environment evidence; do not launch Docker or remote builds solely for calibration. If the Dockerfile/setup was already supplied or pasted and built successfully, preserve it without edits, rebuilds or container runs. Report missing evidence or incompatibility to the creator; calibration itself does not authorize Docker changes or reruns. The creator handles explicitly requested or demonstrably necessary environment repairs within the profile's existing authorization.

## Establish the evaluator

Keep evaluator material inaccessible by instruction to blind solvers. Verify independently on a pristine checkout that:

- the pinned commit passes the base suite;
- the pinned commit fails the new suite for the intended missing behavior;
- the harness emits truthful, usable results.

If the evaluator is unhealthy, stop and report it. Do not repair problem artifacts under this skill.

## Run four blind attempts

Use exactly four fresh `gpt-5.6-sol` subagents at medium reasoning effort. If that model-effort combination is unavailable, stop rather than substituting another model. Hand off the frozen inputs and attempt status to the owner for a host that supports this exact model and effort, such as an appropriately configured Codex host; do not silently change models or duplicate attempts. Give each agent a separate pristine checkout at the same pinned commit and the same description. Give no prior conversation history.

Each blind solver may inspect its assigned repository, implement one best solution, run ordinary repository tests, and install public dependencies when permitted. It must not access:

- `solution.patch`, `test.patch`, hidden tests, or evaluator directories;
- Olympus exports, platform outputs, creator notes, memory, or casebook;
- another solver's checkout, messages, or work;
- the active workspace except for its explicitly supplied description and assigned checkout.

Do not provide hidden-test feedback, candidate-to-candidate feedback, implementation hints, or a corrected second attempt. Environment-only assistance is allowed when needed; give materially identical assistance to every affected solver. An agent may iterate normally against public repository tests within its single attempt.

Run the four attempts concurrently only within available capacity; otherwise schedule them in waves. Four means four total initial attempts, not four per wave. A result is still one sample regardless of how long compilation takes. Mark contamination or infrastructure-only failures invalid and report the smaller valid denominator; do not automatically launch replacement attempts or a second cohort. Any replacement or additional local cohort needs a new explicit user instruction. Do not replace a genuine implementation failure.

## Evaluate independently

After an attempt finishes, apply its complete intended diff to a fresh checkout at the pinned commit, then apply the hidden test patch. Do not repair or complete the candidate. Run both base and new suites in the evaluation environment.

Classify each attempt:

- **Genuine:** both base and new suites pass and inspection finds no demonstrated violation of the stated public contract. A test-aware, incomplete or otherwise incorrect passing candidate is a false positive to report, not a genuine solve.
- **Near solve:** one coherent, localized defect prevents success; one defect may fail several tests or backends.
- **Incomplete:** multiple independent obligations or substantial architecture are missing.
- **Invalid attempt:** contamination or infrastructure prevented a fair, evaluable attempt.
- **Evaluation anomaly:** a hidden filename collision or evaluator defect distorted the result. Exclude the affected attempt from the valid denominator on that revision. After an authorized evaluator repair, replay the retained immutable candidate only as diagnostic re-evaluation, recording its outcome and repaired hashes separately; do not call it a fresh blind attempt or automatically launch a replacement.

A new-suite pass with a base failure is not genuine. Report it as new behavior complete but base-regressed, with the regression identified. Do not infer nearness from the raw failed-test count alone. Inspect the failures and candidate diff to identify independent root causes.

Do not expose complete candidate patches in the report and do not design agent-specific traps from their implementations.

## Interpret the four-attempt result

Require exactly **0 genuine solves from 4 valid blind attempts** on the frozen revision.

- **0/4 valid, fair attempts:** meets the local target. Inspect common failure causes and near solves; ambiguity, hidden constraints, or a broken environment invalidate a hardness conclusion. No near-solve minimum is imposed.
- **1-4/4 genuine solves:** misses the local target. Retain correct solutions as valid; recommend a more demanding coherent repository problem or a justified interaction while keeping at most 12 atomic requirements. Do not add traps to disqualify a correct solution.
- **Fewer than 4 valid attempts:** incomplete measurement, even with zero successes. Report the actual denominator and reasons; do not silently count invalid runs as failures or start replacements.
- **Any incorrect passing candidate:** unresolved false-positive defect. Record the public-contract violation and request fair test repair; do not declare the local gate satisfied merely because genuine solves are zero.

The owner confirmed that calibration is a one-time cohort: all four originally scheduled agents must genuinely fail in valid, fair attempts. A test or evaluator change that affects the verdict makes the original score stale for the repaired revision; an invalid original attempt leaves the measurement incomplete. Any separately authorized replay of retained candidates is diagnostic only and cannot satisfy a fresh calibration gate. Do not automatically replay candidates, replace attempts, or launch another cohort; report the limitation for the user's decision.

This is a local model-specific target, not proof of any platform codename's outcome or of any codename's sequence length. The above-9/10 rating remains an author estimate until supported by evidence.

False-positive hardening is not a remedy for an inherently easy problem whose solutions are genuinely correct. Valid coverage for behavior already required or uniquely discoverable may be added later, but never recommend obscure traps, unrelated obligations, implementation pinning, artificial environment difficulty, or ambiguity merely to reduce solves.

When recommending increased difficulty, prefer this order:

1. Remove only non-contractual implementation recipes or excessive signposting; keep every required behavior clear.
2. Deepen one existing semantic interaction across natural production owners or existing pathways while keeping it observable, deterministic, discoverable, and implementation-independent.
3. If neither is fair and coherent, replace the problem direction instead of bolting on clauses.

This skill never makes those changes. The user remains the middleman and decides what to ask the creator to revise.

## Report and stop

Report:

- the pinned base, description/test/harness hashes, model/settings and evaluator health;
- base/new result and classification for each attempt;
- strict genuine count, near-solve count, and any invalid attempts or anomalies;
- common or localized failure causes without leaking full candidate solutions;
- whether the 0/4 target is met, incomplete, or missed, and the recommended next action.

Stop after the four scheduled attempts and the report. If fewer than four are valid, report the incomplete sample and exclusions; do not silently replace attempts. Do not launch platform runs or modify artifacts. Four attempts are a small local diagnostic sample, not a platform cohort result; local model usage consumes model quota. Do not inspect authenticated platform state, use the Shipd CLI/API, or start any paid platform action. Give the local report and artifacts to the owner; this team kit has no Shipd token allowance.

Changes to the solver-visible requirements or production scope invalidate a claim that this cohort measured the current problem. A fresh cohort is needed before claiming a fresh current calibration, but it requires a new explicit user instruction; record the old measurement as stale rather than automatically starting again. After test-only repairs, replay retained immutable candidates against the repaired evaluator when authorized, labeling this diagnostic re-evaluation rather than new independent solves. Inspect whether any changed assertion adds a new obligation; do not retroactively label a previously compliant candidate a cheat.

Do not automatically launch four new agents for small reference-only fixes, metadata edits, or routine post-upload server findings when the solver-visible problem and evaluator are unchanged. Verify affected reference behavior locally and record evidence reuse. If a required fresh cohort is unavailable or the user disallows runs, report calibration as stale or unmeasured instead of inventing a pass rate.

## Local-Only Team Handoff

Report genuine local successes over valid attempts and the invalid count, with the model, pinned base and artifact hashes. Four samples provide a measured local result with substantial uncertainty, not a reliable estimate of every model or the server population. Do not infer server results from this local sample. The owner performs any platform validation separately; this checker must not locate or load personal platform automation files.

This skill starts no server jobs and spends no Shipd rollout tokens; its agents still consume model usage. Verifier Audit/VLC is prohibited. A healthy local cohort does not authorize upload, Auto Review or server attempts. Send demonstrated gaps back to the creator without directly mutating the frozen task. Because initial review has already approved this task, later calibration findings trigger creator repairs and affected local verification, not another automatic self_review.md cycle. Preserve the original reviewed hashes and record repaired artifacts separately.
