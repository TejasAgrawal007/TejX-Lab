# Docker Environment Setup

For a preserved setup, read only the Dockerfile gate below, to inspect the recorded evidence without rebuilding. Read the rest of this file only when a repository has no successfully built Docker setup yet, when the user explicitly asks for Docker work, or when a concrete build/runtime failure or incompatible image input makes a specific Docker action necessary. For every other task, the preservation rule in CLAUDE.md/AGENTS.md applies: keep the existing Dockerfile and image untouched and verify the task directly in the terminal.

## When Docker work is allowed

If the Dockerfile/setup has already been supplied or pasted and built successfully, leave it untouched. Do not edit, replace, optimize or regenerate the Dockerfile or image inputs, rebuild the image, run containers, or run tests through Docker. This includes a Dockerfile already pasted on the server with a successfully built image. The user's statement that it was built is sufficient to prohibit a repeat, but is not evidence of unrecorded test results. A missing receipt, new task, new chat, review finding, server warning, generic permission to fix findings, or a desire to refresh green results is not necessity.

Docker work is allowed only for an initial setup that has never been built, an explicit user request, or a demonstrated necessity: a concrete build/runtime failure or an actual incompatible image input. Identify the specific reason first, prefer a terminal-only fix, and perform only the necessary local action; this kit never performs server operations, so hand any required server action to the owner. Do not claim stale image evidence validates changed inputs.

For a preserved setup, record missing required image proof or a failing Dockerfile criterion as an unresolved limitation, not PASS or automatic NOT APPLICABLE. Continue feasible terminal work, but do not claim initial approval or completion while an applicable required gate remains unsatisfied. Only an explicit owner instruction can waive or defer such a gate; record that instruction and the unverified scope.

## Writing the Dockerfile

```dockerfile
FROM public.ecr.aws/d3j8x8q7/olympus-base-go:latest
WORKDIR /app
COPY . .
RUN <install dependencies>
CMD ["/bin/bash"]
```

- Base image must match the repository language using the concrete `olympus-base-<language>` suffix:
  - Python: `public.ecr.aws/d3j8x8q7/olympus-base-python:latest`
  - TypeScript / JavaScript: `public.ecr.aws/d3j8x8q7/olympus-base-typescript:latest`
  - Go: `public.ecr.aws/d3j8x8q7/olympus-base-go:latest`
  - Rust: `public.ecr.aws/d3j8x8q7/olympus-base-rust:latest`
  - Java / JVM: `public.ecr.aws/d3j8x8q7/olympus-base-jvm:latest`
  - C++: `public.ecr.aws/d3j8x8q7/olympus-base-cpp:latest`
- Do not use the generic `public.ecr.aws/d3j8x8q7/olympus-base:latest` image or leave a placeholder like `<language>` in the final Dockerfile
- Internet access is available during `docker build`, but not when running the container. Install all dependencies at build time so the image works fully offline at runtime, and never install or invoke package managers at runtime
- When a Dockerfile is being written or repaired under this file's authorization, install at build time what the repository's own tests for the affected areas need, so a solver can run them offline with the pinned toolchain. A solver that cannot run tests runs shorter and misses more, which costs both the sequence length and the pass rate The Target Profile needs. This installs dependencies only: it never runs tests in the build, and this consideration never authorizes a local build or container run on its own
- The built image must work before either `test.patch` or `solution.patch` is applied; patches are applied only after the build
- Use the JUnit reporters already installed in the selected base image when available. For Go repositories, use the preinstalled `go-junit-report`
- Do not install Rust with rustup, `sh.rustup.rs`, or other remote installer scripts when the base image already provides `cargo`. If a repository `rust-toolchain` file would trigger a download, set `RUSTUP_TOOLCHAIN` to a toolchain already installed in the base image
- Do not run, apply, copy explicitly, chmod individually, or otherwise reference `test.sh` or `test.patch` in the Dockerfile. If the grading user must modify the checkout, set repository-wide permissions before dependency installation or compilation without naming challenge artifacts
- Never run tests inside the Dockerfile. Entrypoint is always `CMD ["/bin/bash"]`. Everything works with `--network none` at runtime

## Image work and layer discipline

- Fetch or install every dependency needed by `test.sh` during the build without invoking a test command. Do not compile test targets or use commands such as `cargo test --no-run` in a `RUN` step
- Patches are applied only after the image build, so measure the unavoidable runtime compilation cost of new test files and keep it safely below the grading timeout. Reject a task whose runtime-only test target approaches the hard runtime limit
- Install only libraries and development packages that the selected build actually links. Disable unused optional discovery instead of installing a large dependency tree merely to satisfy an unnecessary probe
- Prefer version-pinned, architecture-matched prebuilt tooling verified by SHA-256 over compiling test reporters from source. If source installation is unavoidable, pin an exact version and use the ecosystem's lock or frozen mode
- Disable debug information and incremental compilation for disposable build artifacts when supported, and keep those settings identical at runtime so reusable artifacts remain valid
- Cap parallel build jobs to fit the grading VM instead of risking an out-of-memory retry
- Set the umask and permissions before creating caches and build outputs, and apply permissions only to required paths. Avoid recursive ownership or permission changes after a large layer, because overlay filesystems copy every touched artifact into another layer
- Keep compilers, package managers, and toolchain roots owned by root and non-writable by the grading user. Provide a separate writable cache or registry directory when the ecosystem requires one
- Create `/var/artifacts` during build with mode `1777` when the platform expects reports there, and configure `/app` as a system Git safe directory so a non-root harness can apply patches
- Never copy host-built or architecture-specific artifacts into the image. Build inside the declared target platform with `docker build --no-cache --platform linux/amd64`
- Preserve dependency-manifest layers above `COPY . .` when practical. Do not trigger a second build just to measure caching

## Rust image rules

Apply only to Rust repositories.

- Use the base image's installed Cargo and Rust toolchain. Do not install another toolchain unless the pinned repository toolchain is genuinely absent
- Set `CARGO_INCREMENTAL=0`, `CARGO_PROFILE_DEV_DEBUG=0`, and `CARGO_PROFILE_TEST_DEBUG=0` before fetching dependencies or compiling non-test targets, and use the same values in graded runs
- Run `cargo fetch` during the build. An optional `cargo build` may compile required production packages, targets, features, and profiles, but no `cargo test` command may appear in a `RUN` step
- Measure fresh runtime test compilation before accepting a large workspace or heavy feature-unification surface, and set `CARGO_BUILD_JOBS` to a measured safe value for the grading VM
- Prefer repository lean or CI profiles and `--no-default-features` only when `test.sh` uses exactly the same profile and feature set
- Keep `/root/.cargo` and `/root/.rustup` root-owned and non-writable. If a model user needs registry writes, configure a writable shadow cache without placing an executable toolchain ahead of trusted binaries
- If exposing trusted Cargo outside the root toolchain, copy the real Cargo executable only when required and preserve Rust compiler loader behavior; do not replace the toolchain with agent-writable shims

## Verified templates

Go:
```dockerfile
FROM public.ecr.aws/d3j8x8q7/olympus-base-go:latest

ENV GOPATH="/root/go"
ENV PATH="/root/go/bin:${PATH}"

WORKDIR /app

COPY . .

RUN go mod vendor

CMD ["/bin/bash"]
```

Rust:
```dockerfile
FROM public.ecr.aws/d3j8x8q7/olympus-base-rust:latest

ENV RUSTUP_HOME="/root/.rustup"
ENV CARGO_HOME="/root/.cargo"
ENV PATH="/root/.cargo/bin:${PATH}"
ENV CARGO_INCREMENTAL=0
ENV CARGO_PROFILE_DEV_DEBUG=0
ENV CARGO_PROFILE_TEST_DEBUG=0

WORKDIR /app

COPY . .

RUN cargo fetch

CMD ["/bin/bash"]
```

## Building and verifying the environment once

Build once:

```bash
docker build --no-cache --platform linux/amd64 -t benchmark-problem .
```

Use the platform's real patch order to prepare an unsolved checkout with test.patch, then a separate solved checkout with solution.patch. Run the actual wrapper in the four verification states from CLAUDE.md inside that image with `--network none`, the real grading user (UID 1000 when applicable), and writable report paths. Keep patches out of Dockerfile build steps.

Record the successful image ID/digest, Dockerfile hash, dependency manifests/lockfiles, base-image identity, target architecture, toolchain/runtime settings, grading user, commands, exit statuses, and offline JUnit evidence in the existing verification record. Image proof describes the environment; terminal proof describes the current task artifacts. Keep these two scopes explicit so a code edit invalidates current test results without discarding valid environment evidence.

Only an actual image-relevant change to dependencies, dependency installation, base image, Dockerfile, architecture, toolchain, permissions, or build/runtime configuration invalidates that environment proof. A newly required dependency is such a change even when the Dockerfile text is unchanged; inspect whether changed source or wrapper behavior affects these inputs. If initial verification fails, diagnose in the terminal first and retry only the missing or failed image proof after repair; a passing solved state cannot replace a missing clean-state proof.

## Environment handoff to the owner

The team never triggers, polls, or uploads remote image builds; remote operations belong to the owner.

- Prepare the required Dockerfile and local environment evidence above; reuse matching proof and do not repeat Docker for review or ordinary code/test edits
- If the owner defers image validation to the server, record that boundary honestly and hand off the environment inputs. Never claim unrun remote validation passed
- If supplied server logs show a build/pull or bootstrap failure, investigate locally and repair permitted harness defects. Preserve the already built Dockerfile and image inputs, report the concrete reason for any necessary Docker or dependency-environment repair, perform only authorized local work, and return the artifacts and evidence; the owner handles required server actions
- Do not trigger duplicate builds to measure caching; record layer reuse only from a build already required for changed inputs

## Dockerfile gate

- D1: The Dockerfile starts from the correct concrete language-specific Olympus base image, not the generic base image
- D2: `WORKDIR` is `/app`
- D3: Dependencies are installed during build, never at runtime, and pre-installed base-image JUnit reporters are reused where available
- D4: The container works without network access at runtime
- D5: The image builds and works before `test.patch` or `solution.patch` is applied; the Dockerfile does not run tests, apply patches, chmod challenge files, or reference either patch
- D6: The Dockerfile ends with `CMD ["/bin/bash"]`
- D7: The image fetches or installs all required dependencies without invoking any test command during the build
- D8: Build-time tools and downloads are version-pinned, architecture-correct, and checksum-verified when prebuilt artifacts are fetched
- D9: Debug and incremental build output is disabled where appropriate, build jobs fit the grading VM, and runtime fingerprint variables exactly match any build-time compilation
- D10: Toolchains remain root-owned, writable caches are separated, `/var/artifacts` is usable by the grading UID, and `/app` is configured as a system Git safe directory
- D11: Permissions are set before large caches are created; no recursive post-build chmod or chown duplicates large overlay layers
- D12: No host-built artifact is copied into the image. Initial or changed-environment proof includes a successful no-cache `linux/amd64` build; matching prior proof is reused without a rebuild
- D13: Fetch-only builds for huge workspaces are backed by a measured fresh new-test compile floor safely below the runtime timeout
- D14: The image is built from a fresh clone at the pinned commit, so local node_modules, .venv, or build output cannot enter through `COPY . .`
- D15: Every dependency the tests or solution need is installed by the Dockerfile; solution.patch never edits a manifest or lockfile to add one
- D16: Clean and solved states were verified as the grading user, UID 1000 when applicable, with every path the tests read or write owned by or writable for that user
